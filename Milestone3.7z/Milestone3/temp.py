from mobility.direction import steerToBearing, calcBayDistance, drive_distance, turnAngle_encoder, rowIndex, turnSearch, drive_distance_wBearing, turnSearchDirection
from enum import IntEnum
from DFRobot_RaspberryPi_DC_Motor import THIS_BOARD_TYPE, DFRobot_DC_Motor_IIC as Board
import traceback
from time import sleep, monotonic, time
import csv

''' camera modules '''
from vision.processing_module import process_frame, Obstacle
from vision.camera_module import Camera
import cv2
from vision.RB import calcShelfMarkersRB, draw_overlay, calcPickingMarkersRB, calcPackingStationRB, calcWallR, detectObject

''' collection modules '''
from collection.collection import level_1, level_2, level_3, centre, open_grabber, close_grabber, trigger_ping, ramp_height



# CONSTANTS (in m)
#TODO: MEASURE ALL OF THESE VALUES
STATION_ARRIVE_DIST = 0.10
STATION_DEPART_DIST = 0.5
RAMP_ARRIVE_DIST = 0.1
BEARING_LIMIT = 3
STATION_ROW_DIST = 1.2
SHELF_GAP = 0.55
STATION_DIST = 0.3

''' VALUES FACING WALL OPPOSITE TO PACKING STATION '''
ROW_0_DIST_o = 1.43
ROW_1_DIST_o = 0.8
ROW_2_DIST_o = 0.33
#TODO: MEASURE ALL OF THESE

''' VALUES FACING WALL CLOSEST TO PACKING STATION '''
ROW_0_DIST = 0.33
ROW_1_DIST = 0.8
ROW_2_DIST = 1.43
#TODO: MEASURE ALL OF THESE

class RobotMode(IntEnum):
    SEARCH_STATION = 0
    CHECK_ROW = 1
    TO_RAMP = 2
    ASCEND_RAMP = 3
    COLLECT_ITEM = 4
    DESCEND_RAMP = 5
    SEARCH_SHELF = 6
    TO_SHELF = 7
    SEARCH_MARKER = 8
    DRIVE_TO_BAY = 9
    ARRIVE_BAY = 10
    DROP_ITEM = 11
    EXIT_ROW = 12
    FIND_ORIGIN = 13
    DEBUG_STOP = 14
    DEBUG_TEST = 15

if THIS_BOARD_TYPE:
  board = Board(1, 0x10)    # RaspberryPi select bus 1, set address to 0x10
else:
  board = Board(7, 0x10)    # RockPi select bus 7, set address to 0x10

def board_detect():
  l = board.detecte()
  print("Board list conform:")
  print(l)

''' print last operate status, users can use this variable to determine the result of a function call. '''
def print_board_status():
  if board.last_operate_status == board.STA_OK:
    print("board status: everything ok")
  elif board.last_operate_status == board.STA_ERR:
    print("board status: unexpected error")
  elif board.last_operate_status == board.STA_ERR_DEVICE_NOT_DETECTED:
    print("board status: device not detected")
  elif board.last_operate_status == board.STA_ERR_PARAMETER:
    print("board status: parameter error, last operate no effective")
  elif board.last_operate_status == board.STA_ERR_SOFT_VERSION:
    print("board status: unsupport board framware version")




def bayTurn(TARGET_BAY):
    TARGET_SHELF_INDEX = TARGET_BAY[0]
    if TARGET_SHELF_INDEX % 2 == 0:
        direction = 'left'
    else:
        direction = 'right'

    return direction

# SIMULATED ORDER
ordersDummy = [(1, (4,3), 0, 'Cube'), (1, (5,0), 2, 'Ball'), (1, (5,3), 0, 'Oil Bottle') ]
ORDER_INDEX = 0

def processOrder(orders):
    currentOrder = orders[ORDER_INDEX]
    TARGET_STATION_IDX = currentOrder[0] - 1
    TARGET_BAY = currentOrder[1]
    TARGET_BAY_HEIGHT = currentOrder[2]
    objectOrderFile = currentOrder[3]
    return TARGET_STATION_IDX, TARGET_BAY, TARGET_BAY_HEIGHT, objectOrderFile


def readWithCsv():
    orders = []
    with open("Order_1_2025.csv", mode="r", encoding="utf-8-sig") as csv_file:
        x = 0
        csv_reader = csv.reader(csv_file)

        for row in csv_reader:
                if x == 0:
                        x = 1
                else:
                        order = (int(row[1]), (int(row[2]), int(row[3])), int(row[4]), row[5])
                        orders.append(order)
    return orders





def setup_gpio(LED_PINS):
    """Configures Raspberry Pi GPIO pins for LED output."""
    try:
        import RPi.GPIO as GPIO
        GPIO_AVAILABLE = True
    except ImportError:
        print("Warning: RPi.GPIO library not found. LED control disabled.")
        GPIO_AVAILABLE = False
    if GPIO_AVAILABLE:
        GPIO.setmode(GPIO.BCM)
        for pin in LED_PINS.values():
            GPIO.setup(pin, GPIO.OUT)
            GPIO.output(pin, GPIO.LOW)

def toggle_led(char_key):
    """Toggles the state of a specific LED."""
    pin = LED_PINS[char_key]
    current_state = LED_STATE[char_key]
    
    new_state = not current_state
    
    if GPIO_AVAILABLE:
        gpio_level = GPIO.HIGH if new_state else GPIO.LOW
        GPIO.output(pin, gpio_level)
    
    LED_STATE[char_key] = new_state
    state_str = "ON" if new_state else "OFF"
    print(f"LED '{char_key}' (Pin {pin}) toggled {state_str}")





if __name__ == "__main__":
    try:
        board_detect()

        while board.begin() != board.STA_OK:    # Board begin and check board status
            print_board_status()
            print("board begin faild")
            sleep(2)
        print("board begin success")

        board.set_encoder_enable(board.ALL)                 # Set selected DC motor encoder enable
        # board.set_encoder_disable(board.ALL)              # Set selected DC motor encoder disable
        board.set_encoder_reduction_ratio(board.ALL, 50)    # Set selected DC motor encoder reduction ratio, test motor reduction ratio is 43.8

        board.set_moter_pwm_frequency(2000)   # Set DC motor pwm frequency to 1000HZ

        # initialise camera processing
        camera = Camera()

        # Target frequency in Hz
        target_freq = 20.0
        period = 1.0 / target_freq

        plot_options = {
            'print_data': False,
            'plot_contours': True,          # Master switch for all shape drawing
            'plot_exact_contours': True,    # Draw exact contours when available
            'plot_approximated_shapes': False,  # Fall back to approximated shapes
            'plot_centers': True,           # Draw center points
            'plot_labels': True,            # Draw text labels
            'plot_trajectory': False,        # Draw trajectory
            'plot_centre_reference': False   # Draw center reference lines
        }

        robotMode = RobotMode.SEARCH_STATION
        level_3()
        sleep(1)
        aligned_frames = 0
        prev_aligned_d = None

        ''' deque attempt '''
        from collections import deque
        ACQ_BEARING_LIMIT = max(12, BEARING_LIMIT) 
        ALIGN_FRAMES = 2
        MISS_B4_SEARCH = 3

        ps_misses = 0
        aligned_run = 0
        d_buf = deque(maxlen=3)
        nextFrameStation = False

        # simple smoothing
        b_filt = None
        d_filt = None
        ALPHA_B = 0.4
        ALPHA_D = 0.4

        turning_flag = False

        ''' LED INITIALISATION '''
        try:
            import RPi.GPIO as GPIO
            GPIO_AVAILABLE = True
        except ImportError:
            print("Warning: RPi.GPIO library not found. LED control disabled.")
            GPIO_AVAILABLE = False

        # --- LED Pin Definitions (BCM numbering scheme) ---
        LED_PINS = {
            'r': 22,  # Red LED on GPIO 17
            'g': 17,  # Green LED on GPIO 27
            'y': 27   # Yellow LED on GPIO 22
        }
        LED_STATE = {key: False for key in LED_PINS}
        setup_gpio(LED_PINS)

        led_flag = False

        last_row_seen_t = None
        tracking_row = False
        acq_frames = 0
        last_cmd = (0.0, 0.0)
        GRACE_S = 0.25

        # new:
        acq_bearing = 0.0         # bearing captured at acquisition
        settle_until = 0.0        # timestamp until which we run "settle" mode
        SETTLE_MS = 0.18          # ~180 ms

        collectPrepFlag = False
        wallCheckFlag = False
        collectFlag = False

        while True:
            #usD = trigger_ping()/100
            #print('robotMode', robotMode)
            loop_start = time()
            frame = camera.capture_frame()
            obstacles, trajectory = process_frame(frame)

            frame_with_overlay = draw_overlay(frame.copy(), obstacles, trajectory, plot_options)            

            # Calculate and display FPS
            current_fps = 1.0 / (time() - loop_start)
            #fps_smooth = fps_smooth * (1 - fps_alpha) + current_fps * fps_alpha
            cv2.putText(frame_with_overlay, f'FPS: {current_fps:.1f}', 
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            # Display results
            cv2.imshow('Vision System', frame_with_overlay)

            shelfMarkersRB = calcShelfMarkersRB(obstacles)
            pickingStationRB = calcPickingMarkersRB(obstacles)
            psRB = calcPackingStationRB(obstacles)
            wallR = calcWallR(obstacles)
            #print('shelfMarkerRB is', shelfMarkersRB)

            ''' order config '''

            #orders = readWithCsv()

            TARGET_STATION_IDX, TARGET_BAY, TARGET_BAY_HEIGHT, objectOrderFile = processOrder(ordersDummy)


            if robotMode == RobotMode.DEBUG_TEST:
                sleep(2)
                turnAngle_encoder(board, 90, 60)
                sleep(2)
                turnAngle_encoder(board, -90, 60)
                sleep(2)
                turnAngle_encoder(board, 180, 60)
                sleep(2)
                turnAngle_encoder(board, -180, 60)
                sleep(2)
                robotMode = RobotMode.DEBUG_STOP

            if robotMode == RobotMode.DEBUG_STOP:
                board.motor_stop(board.ALL)
            

            elif robotMode == RobotMode.SEARCH_STATION:
                if led_flag == False:
                    print("current order is", ordersDummy[ORDER_INDEX])
                    toggle_led('y') # yellow on
                    led_flag = True
                if psRB:
                    board.motor_stop(board.ALL)
                    turning_flag = False
                    disregard, psRBb = psRB # disregard camera distance
                    psRBd = trigger_ping()/100
                    print("packing station values distance:", psRBd, "bearing:", psRBb)

                    if abs(psRBb) < BEARING_LIMIT:
                        # if abs(psRBb) > BEARING_LIMIT:
                        #     print("AM I ABOVE BEARING LIMIT")
                        #     aligned = steerToBearing(psRBb, BEARING_LIMIT, board)
                        # else:
                        print("I AM ALIGNED")
                        if psRBd <= RAMP_ARRIVE_DIST:
                            board.motor_stop(board.ALL)
                            robotMode = RobotMode.CHECK_ROW
                        else:
                            print("i am driving this distance:", psRBd - RAMP_ARRIVE_DIST)
                            drive_distance(board, psRBd - RAMP_ARRIVE_DIST, 100)
                            sleep(1)
                            turnAngle_encoder(board, 90, 60)
                            sleep(1)
                            drive_distance(board, 0.2, 75)
                            board.motor_stop(board.ALL)
                            sleep(1)
                            led_flag = False
                            robotMode = RobotMode.CHECK_ROW #TODO: CHANGE THIS TO CHECK ROW
                    else:
                        if psRBb < 0:
                            turnSearchDirection(50, board, 'L')
                        elif psRBb > 0:
                            turnSearchDirection(50, board, 'R')
                else:
                    if turning_flag == False:
                        print("start turning")
                        turnSearch(60, board)
                        turning_flag = True

            # elif robotMode == RobotMode.CHECK_ROW:
            #     distFromWall = 0.65
            #     sleep(0.5)
            #     usDhere = readDistance()
            #     wallD = usDhere
            #     print("turned wall with sleep", wallD)
            #     print("turned wall without sleep", usD)
            #     distToDrive = distFromWall - wallD
            #     print("distance to drive backwards is", distToDrive)
            #     drive_distance(board, -distToDrive, 75)
            #     board.motor_stop(board.ALL)
            #     sleep(0.15)
            #     turnAngle_encoder(board, 90, 75)
            #     sleep(0.25)
            #     robotMode = RobotMode.TO_RAMP
                




            elif robotMode == RobotMode.CHECK_ROW:
                now = monotonic()
                row = shelfMarkersRB[1]  # middle row marker group

                if row is not None:
                    rowD, rowB = row

                    # --- Rising edge: marker just (re)appeared ---
                    if not tracking_row:
                        board.motor_stop(board.ALL)
                        sleep(0.08)                 # kill residual spin longer to reduce inertia
                        tracking_row  = True
                        acq_frames    = 0
                        b_filt        = None
                        acq_bearing   = rowB        # MEMORY FRAME: lock first bearing
                        settle_until  = now + SETTLE_MS

                    last_row_seen_t = now
                    acq_frames     += 1

                    # Distance error
                    dist_delta = rowD - STATION_ROW_DIST

                    # Arrival gate
                    if abs(dist_delta) <= 0.03:
                        print("i have arrived at check row distance")
                        board.motor_stop(board.ALL)
                        sleep(0.15)
                        turnAngle_encoder(board, -90, 60)
                        sleep(0.3)
                        tracking_row = False
                        drive_distance(board, 0.20, 75)
                        robotMode    = RobotMode.TO_RAMP
                    else:
                        # --- Choose bearing for this frame ---
                        if now < settle_until:
                            # SETTLE WINDOW: use memory bearing; low gain, low speed, low clip
                            b_use       = acq_bearing
                            base_speed  = 40
                            kp_use      = 1.0
                            vL, vR = drive_distance_wBearing(board,
                                                            dist_delta=dist_delta,
                                                            bearing_deg=b_use,
                                                            base_speed=base_speed,
                                                            kp_bearing=kp_use,
                                                            max_speed=75,
                                                            min_speed=40)  # allow tight arc
                        else:
                            # After settle: very light filter, then soft-start ramp for 5 frames
                            if b_filt is None:
                                b_filt = rowB
                            else:
                                ALPHA_B = 0.35
                                # limit how fast bearing can change to avoid snap-turns on blur spikes
                                delta_b = rowB - b_filt
                                MAX_DB  = 6.5  # deg/frame clamp
                                if   delta_b >  MAX_DB: rowB = b_filt + MAX_DB
                                elif delta_b < -MAX_DB: rowB = b_filt - MAX_DB
                                b_filt = (1-ALPHA_B)*b_filt + ALPHA_B*rowB

                            # Soft-start ramp: 5 frames after acquisition
                            ramp = min(1.0, max(0.0, (acq_frames - 1) / 5.0))
                            base_speed = 45 + ramp * (65 - 45)   # 45 -> 65
                            kp_use     = 0.9 + ramp * (2.2 - 0.9) # 0.9 -> 2.2

                            vL, vR = drive_distance_wBearing(board,
                                                            dist_delta=dist_delta,
                                                            bearing_deg=b_filt,
                                                            base_speed=base_speed,
                                                            kp_bearing=kp_use,
                                                            max_speed=75,
                                                            min_speed=40)
                        last_cmd = (vL, vR)

                else:
                    # Marker not visible this frame
                    if tracking_row and last_row_seen_t is not None and (now - last_row_seen_t) < GRACE_S:
                        # GRACE: keep last forward+steer for a moment to bring marker back into FOV
                        vL, vR = last_cmd
                        board.motor_movement([board.M1], board.CCW, vL)
                        board.motor_movement([board.M2], board.CW,  vR)
                    else:
                        # Fully lost: very gentle search, not a hard spin
                        tracking_row = False
                        board.motor_movement([board.M1], board.CCW,  50)
                        board.motor_movement([board.M2], board.CCW,  50)



            

            # elif robotMode == RobotMode.TO_RAMP:
            #     print("TO RAMP MODE")
            #     usD = trigger_ping()/100
            #     if wallR:
            #         if usD < 0.9 and usD > 0.6 and wallCheckFlag == False: #  
            #             wallR = trigger_ping()/100
            #             print("detected wall distance is", wallR)
            #             #wallWusD = usD
            #             #print("detected with ultrasonic is ", wallWusD)
            #             pickingBayDist = 0.07 + (TARGET_STATION_IDX-2) * -1 * STATION_DIST
            #             print("pickingBayDist is", pickingBayDist)
            #             deltaDist = wallR - pickingBayDist
            #             drive_distance(board, deltaDist, 100)
            #             wallCheckFlag = True
            #         elif wallCheckFlag == True:
            #             print("start turning left")
            #             sleep(0.5)
            #             board.motor_stop(board.ALL)
            #             sleep(0.5)
            #             turnAngle_encoder(board, -90, 75)
            #             sleep(0.5)
            #             board.motor_stop(board.ALL)
            #             sleep(0.5)
            #             drive_distance(board, -0.08, 55)
            #             sleep(0.5)
            #             robotMode = RobotMode.ASCEND_RAMP
            #     else:
            #         print("turning for wall search")
            #         turnSearch(60, board)


            elif robotMode == RobotMode.TO_RAMP:
                if wallR:
                    usD = trigger_ping()/100
                    pickingBayDist = 0.07 + (TARGET_STATION_IDX-2) * -1 * STATION_DIST
                    print("pickingBayDist is", pickingBayDist)
                    while usD > pickingBayDist:
                        board.motor_movement([board.M1], board.CCW, 75)
                        board.motor_movement([board.M2], board.CW,  75)
                        usD = trigger_ping()/100
                    board.motor_stop(board.ALL)
                    sleep(0.5)
                    turnAngle_encoder(board, -90, 60)
                    sleep(0.5)
                    board.motor_stop(board.ALL)
                    sleep(0.5)
                    drive_distance(board, -0.08, 55)
                    sleep(0.5)
                    robotMode = RobotMode.ASCEND_RAMP

                else:
                    print("turning for wall search")
                    turnSearch(60, board)

            elif robotMode == RobotMode.ASCEND_RAMP:
                print("ascend ramp mode")
                pickingStation = pickingStationRB[TARGET_STATION_IDX]
                if pickingStation:
                    board.motor_stop(board.ALL)
                    sleep(0.5)
                    pickingStationBearing = pickingStation[1]
                    print("picking station bearing is", pickingStationBearing)
                    pickingStationDistance = pickingStation[0]
                    if abs(pickingStationBearing) < BEARING_LIMIT:
                        board.motor_stop(board.ALL)
                        sleep(0.5)
                        print("i am aligned")
                        objectR, objectB = detectObject(obstacles, objectOrderFile)
                        if objectB:
                            board.motor_stop(board.ALL)
                            sleep(0.5)
                            print("object is detected")
                            objectR, objectB = detectObject(obstacles, objectOrderFile)
                            print("object name is", objectOrderFile)
                            print("objectR", objectR, "objectB", objectB)
                            if abs(objectB) < 3:
                                print("object is aligned")
                                good = False
                                while not good:
                                    object_distance = trigger_ping()
                                    print(object_distance, type(object_distance))
                                    if object_distance > 25 and object_distance < 70:
                                        good = True
                                        if collectPrepFlag == False:
                                            ramp_height()
                                            collectPrepFlag = True
                                        if object_distance > STATION_ARRIVE_DIST:#pickingStationDistance > STATION_ARRIVE_DIST:
                                            #drive_distance(board, pickingStationDistance - STATION_ARRIVE_DIST, 100)
                                            drive_distance(board, (object_distance)/100 - 0.075,100)
                                            sleep(1)
                                            board.motor_stop(board.ALL)
                                            collectPrepFlag = False
                                            robotMode = RobotMode.COLLECT_ITEM
                                        else:
                                            board.motor_stop(board.ALL)
                                            collectPrepFlag = False
                                            robotMode = RobotMode.COLLECT_ITEM
                                    else:
                                        if objectB < 0:
                                            turnSearchDirection(55, board, 'L')
                                        elif objectB > 0:
                                            turnSearchDirection(55, board, 'R')
                        else:
                            print("object is not detected")
                            turnSearchDirection(55, board, 'L')
                    else:
                        if pickingStationBearing < 0:
                            turnSearchDirection(55, board, 'L')
                        elif pickingStationBearing > 0:
                            turnSearchDirection(55, board, 'R')
                else:
                   turnSearch(50, board)

            
            elif robotMode == RobotMode.COLLECT_ITEM:
               if led_flag == False:
                   toggle_led('y') # yellow off
                   toggle_led('g') # green on
                   led_flag = True
               print("collect item mode")
               if collectFlag == False:
                print("collect flag is false")
                board.motor_stop(board.ALL)
                objectD = trigger_ping()/100             
                open_grabber()
                sleep(2)
                centre()
                sleep(1)
                print("centered")
                collectFlag = True
               elif collectFlag == True:
                print("collect flag is true")
                drive_distance(board, objectD, 60)
                sleep(2)
                #TODO: CHECK IF ROBOT CAN SEE OBJECT, CALC DIST FROM SAID OBJECT
                close_grabber(objectOrderFile)
                sleep(2)
                drive_distance(board, -0.05, 60)
                sleep(1)
                level_2()
                sleep(1)
                led_flag = False
                robotMode = RobotMode.DESCEND_RAMP

            
            # elif robotMode == RobotMode.DESCEND_RAMP:
            #     pickingStation = pickingStationRB[TARGET_STATION_IDX]
            #     if pickingStation:
            #         pickingStationBearing = pickingStation[1]
            #         pickingStationDistance = pickingStation[0]
            #         if pickingStationDistance < STATION_DEPART_DIST:
            #             drive_distance(board, STATION_DEPART_DIST - pickingStationDistance, 100)
            #             sleep(1)
            #             board.motor_stop(board.ALL)
            #             robotMode = RobotMode.SEARCH_SHELF
            #         else:
            #            board.motor_stop(board.ALL)
            #            robotMode = RobotMode.SEARCH_SHELF
            #     else:
            #        turnSearch(80, board)

            elif robotMode == RobotMode.DESCEND_RAMP:
                if led_flag == False:
                    toggle_led('g') # green off
                    toggle_led('y') # yellow on
                    led_flag = True
                print("descend ramp")
                sleep(1)
                drive_distance(board, -0.4, 65)
                sleep(2)
                level_3()
                sleep(1)
                usD = trigger_ping()/100
                print("detected distance is", usD)
                if usD > 0.55:
                    while usD > 0.55:
                        board.motor_movement([board.M1], board.CCW, 60)
                        board.motor_movement([board.M2], board.CW,  60)
                        usD = trigger_ping()/100
                    board.motor_stop(board.ALL)
                elif usD < 0.55:
                    while usD < 0.55:
                        board.motor_movement([board.M1], board.CW, 60)
                        board.motor_movement([board.M2], board.CCW, 60)
                        usD = trigger_ping()/100
                    board.motor_stop(board.ALL)
                robotMode = RobotMode.SEARCH_SHELF



            elif robotMode == RobotMode.SEARCH_SHELF:
                print("search shelf")
                TARGET_ROW_INDEX = rowIndex(TARGET_BAY)
                print("target row is", TARGET_ROW_INDEX)
                print("target station is", TARGET_STATION_IDX)
                turnAngle_encoder(board, 90, 60)
                sleep(1)

                if TARGET_STATION_IDX == 2:
                    if TARGET_ROW_INDEX == 0:
                        turnAngle_encoder(board, 90, 60)
                        sleep(1)
                        robotMode = RobotMode.TO_SHELF
                    elif TARGET_ROW_INDEX == 1:
                        drive_distance(board, -SHELF_GAP, 100)
                        sleep(1)
                        if wallR:
                            usD = trigger_ping()/100
                            if usD > ROW_1_DIST:
                                while usD > ROW_1_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_1_DIST
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_1_DIST:
                                while usD < ROW_1_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = ROW_1_DIST - usDChange
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            sleep(1)
                            turnAngle_encoder(board, 90, 60)
                            sleep(1)
                            robotMode = RobotMode.TO_SHELF
                        else:
                            turnSearch(60, board)
                    elif TARGET_ROW_INDEX == 2:
                        sleep(2)
                        drive_distance(board, -SHELF_GAP, 75)
                        sleep(1)
                        if wallR:
                            usD = trigger_ping()/100
                            if usD > ROW_2_DIST:
                                while usD > ROW_2_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_2_DIST
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_2_DIST:
                                while usD < ROW_2_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = ROW_2_DIST - usDChange
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            sleep(1)
                            turnAngle_encoder(board, 90, 60)
                            sleep(1)
                            robotMode = RobotMode.TO_SHELF
                        else:
                            turnSearch(60, board)
                
                elif TARGET_STATION_IDX == 1:
                    if TARGET_ROW_INDEX == 0:
                        if wallR:
                            usD = trigger_ping()/100
                            if usD > ROW_0_DIST:
                                while usD > ROW_0_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_0_DIST
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_0_DIST:
                                while usD < ROW_0_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = ROW_0_DIST - usDChange
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                        sleep(1)
                        turnAngle_encoder(board, 90, 60)
                        sleep(1)
                        robotMode = RobotMode.TO_SHELF
                    elif TARGET_ROW_INDEX == 1:
                        if wallR:
                            usD = trigger_ping()/100
                            print("first usD is", usD)
                            if usD > ROW_1_DIST:
                                while usD > ROW_1_DIST:
                                    usDChange = usD
                                    print("usD top of loop is", usD)
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        print("we are in usdChange")
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_1_DIST
                                        print("delta is", delta_r)
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_1_DIST:
                                while usD < ROW_1_DIST:
                                    usDChange = usD
                                    print("usD top of loop is", usD)
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        print("we are in usdChange")
                                        sleep(0.5)
                                        delta_r = ROW_1_DIST - usDChange
                                        print("delta is", delta_r)
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                        sleep(1)
                        turnAngle_encoder(board, 90, 60)
                        sleep(1)
                        robotMode = RobotMode.TO_SHELF
                    elif TARGET_ROW_INDEX == 2:
                        if wallR:
                            usD = trigger_ping()/100
                            if usD > ROW_2_DIST:
                                while usD > ROW_2_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_2_DIST
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_2_DIST:
                                while usD < ROW_2_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = ROW_2_DIST - usDChange
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                        sleep(1)
                        turnAngle_encoder(board, 90, 60)
                        sleep(1)
                        robotMode = RobotMode.TO_SHELF

                elif TARGET_STATION_IDX == 0:
                    if TARGET_ROW_INDEX == 0:
                        if wallR:
                            print("wall is detected")
                            usD = trigger_ping()/100
                            print("first usd distance is", usD)
                            if usD > ROW_0_DIST:
                                while usD > ROW_0_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_0_DIST
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_0_DIST:
                                while usD < ROW_0_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = ROW_0_DIST - usDChange
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            sleep(1)
                            turnAngle_encoder(board, 90, 60)
                            sleep(1)
                            robotMode = RobotMode.TO_SHELF
                        else:
                            print("wall is not detected")
                            turnSearch(60, board)
                        
                    elif TARGET_ROW_INDEX == 1:
                        if wallR:
                            usD = trigger_ping()/100
                            print("WHAT IS GOING ON FIRST", usD)
                            print("wallR is", wallR)
                            if usD > ROW_1_DIST:
                                while usD > ROW_1_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        print("we are in usdChange")
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_1_DIST
                                        print("delta is", delta_r)
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_1_DIST:
                                while usD < ROW_1_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        print("we are in usdChange")
                                        sleep(0.5)
                                        delta_r = ROW_1_DIST - usDChange
                                        print("delta is", delta_r)
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                        sleep(1)
                        turnAngle_encoder(board, 90, 60)
                        sleep(1)
                        robotMode = RobotMode.TO_SHELF
                    elif TARGET_ROW_INDEX == 2:
                        if wallR:
                            usD = trigger_ping()/100
                            if usD > ROW_2_DIST:
                                while usD > ROW_2_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CCW, 60)
                                    board.motor_movement([board.M2], board.CW,  60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = usDChange - ROW_2_DIST
                                        drive_distance(board, delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                            elif usD < ROW_2_DIST:
                                while usD < ROW_2_DIST:
                                    usDChange = usD
                                    board.motor_movement([board.M1], board.CW, 60)
                                    board.motor_movement([board.M2], board.CCW, 60)
                                    usD = trigger_ping()/100
                                    if usDChange > 1.1*usD or usDChange < 0.9*usD:
                                        sleep(0.5)
                                        delta_r = ROW_2_DIST - usDChange
                                        drive_distance(board, -delta_r, 75)
                                        sleep(1)
                                        break
                                board.motor_stop(board.ALL)
                        sleep(1)
                        turnAngle_encoder(board, 90, 60)
                        sleep(1)
                        robotMode = RobotMode.TO_SHELF

            
            elif robotMode == RobotMode.TO_SHELF:
                TARGET_ROW_INDEX = rowIndex(TARGET_BAY)
                TARGET_BAY_INDEX = TARGET_BAY[1]
                shelfMarkerRB = shelfMarkersRB[TARGET_ROW_INDEX]
                if shelfMarkerRB != None:
                    shelfR = shelfMarkerRB[0]
                    print("shelfR", shelfR)
                    shelfB = shelfMarkerRB[1]
                    print("shelf bearing is", shelfB)
                    if abs(shelfB) < BEARING_LIMIT:
                        board.motor_stop(board.ALL)
                        sleep(0.2)
                        robotMode = RobotMode.DRIVE_TO_BAY
                    else:
                        if shelfB < 0:
                            print("correcting to left")
                            turnSearchDirection(50, board, 'L')
                        elif shelfB > 0:
                            print("correcting to right")
                            turnSearchDirection(50, board, 'R')
                else:
                    turnSearch(60, board)
            
            elif robotMode == RobotMode.DRIVE_TO_BAY:
                if shelfMarkersRB[TARGET_ROW_INDEX]:
                    shelfB = shelfMarkersRB[TARGET_ROW_INDEX][1]
                    shelfD = shelfMarkersRB[TARGET_ROW_INDEX][0]
                    bayDistance = calcBayDistance(TARGET_BAY)
                    print("bay distance is", bayDistance)
                    print("distance to drive is", shelfD-bayDistance)
                    if shelfD > bayDistance:
                        print("driving to bay")
                        drive_distance(board, shelfD-bayDistance, 75)
                        sleep(1)
                        board.motor_stop(board.ALL)
                        robotMode = RobotMode.ARRIVE_BAY
                    else:
                        print("Arrived at bay")
                        board.motor_stop(board.ALL)
                        robotMode = RobotMode.ARRIVE_BAY
            
            elif robotMode == RobotMode.ARRIVE_BAY:
                TARGET_SHELF_INDEX = TARGET_BAY[0]
                directionM = TARGET_SHELF_INDEX % 2
                if directionM == 0:
                    direction = 'left'
                elif directionM == 1:
                    direction = 'right'
                
                if direction == 'left':
                    turnAngle_encoder(board, -90, 60)
                    sleep(1)
                    board.motor_stop(board.ALL)
                    robotMode = RobotMode.DROP_ITEM
                elif direction == 'right':
                    turnAngle_encoder(board, 90, 60)
                    sleep(1)
                    board.motor_stop(board.ALL)
                    robotMode = RobotMode.DROP_ITEM

            elif robotMode == RobotMode.DROP_ITEM:
                if led_flag == False:
                    toggle_led('r') # red on
                    toggle_led('y') # yellow off
                    led_flag = True
                usD = trigger_ping()/100
                print("initial desiredShelfD usD", usD)
                desiredShelfD = 0.24
                if usD < desiredShelfD:
                    while usD < desiredShelfD:
                        board.motor_movement([board.M1], board.CW,  50)
                        board.motor_movement([board.M2], board.CCW, 50)
                        usD = trigger_ping()/100
                elif usD > desiredShelfD:
                    while usD > desiredShelfD:
                        board.motor_movement([board.M1], board.CCW,  50)
                        board.motor_movement([board.M2], board.CW, 50)
                        usD = trigger_ping()/100

                # deltaDist = usD-0.24
                # drive_distance(board, deltaDist, 55)
                
                sleep(3)
                print("about to change arm height")

                if TARGET_BAY_HEIGHT == 0:
                    level_1()
                elif TARGET_BAY_HEIGHT == 1:
                    level_2()
                elif TARGET_BAY_HEIGHT == 2:
                    level_3()
                sleep(3)
                if TARGET_BAY_HEIGHT != 0:
                    usD = trigger_ping()/100
                    desiredMoveInD = 0.175
                    print("initial desiredMoveInD usD", usD)
                    if usD < desiredMoveInD:
                        while usD < desiredMoveInD:
                            board.motor_movement([board.M1], board.CW,  50)
                            board.motor_movement([board.M2], board.CCW, 50)
                            usD = trigger_ping()/100
                    elif usD > desiredMoveInD:
                        while usD > desiredMoveInD:
                            board.motor_movement([board.M1], board.CCW,  50)
                            board.motor_movement([board.M2], board.CW, 50)
                            usD = trigger_ping()/100
                elif TARGET_BAY_HEIGHT == 0:
                    drive_distance(board, 0.25, 75)
                sleep(3)
                print("about to open grabber")
                open_grabber()
                sleep(3)
                # usD = trigger_ping()/100
                # desiredShelfOutD = 0.15
                # print("initial desiredShelfOutD usD", usD)
                # if usD < desiredShelfOutD:
                #     while usD < desiredShelfOutD:
                #         board.motor_movement([board.M1], board.CW,  50)
                #         board.motor_movement([board.M2], board.CCW, 50)
                #         usD = trigger_ping()/100
                # elif usD > desiredShelfOutD:
                #     while usD > desiredShelfOutD:
                #         board.motor_movement([board.M1], board.CCW,  50)
                #         board.motor_movement([board.M2], board.CW, 50)
                #         usD = trigger_ping()/100
                drive_distance(board, -0.15, 55)
                sleep(2)
                if direction == 'left': angle = 90
                if direction == 'right': angle = -90

                if TARGET_BAY_INDEX != 3:
                    turnAngle_encoder(board, angle, 60)
                    sleep(0.5)
                    board.motor_stop(board.ALL)
                    if TARGET_BAY[1] == 2 or TARGET_BAY[1] == 3:
                        drive_distance(board, -0.3, 75)
                        sleep(2)
                        board.motor_stop(board.ALL)
                    sleep(1)
                    level_3()
                    led_flag = False
                    print("AM I HERE TO GO TO EXIT ROW??")
                    robotMode = RobotMode.EXIT_ROW
                elif TARGET_BAY_INDEX == 3:
                    if direction == 'left': angle = -90
                    if direction == 'right': angle = 90
                    turnAngle_encoder(board, angle, 60)
                    sleep(0.5)
                    drive_distance(board, 0.15, 75)
                    sleep(1)
                    turnAngle_encoder(board, 180, 60)
                    sleep(0.5)
                    board.motor_stop(board.ALL)
                    sleep(1)
                    drive_distance(board, -0.25, 75)
                    sleep(0.5)
                    board.motor_stop(board.ALL)
                    sleep(0.5)
                    level_3()
                    led_flag = False
                    print("AM I HERE TO GO TO EXIT ROW??")
                    robotMode = RobotMode.EXIT_ROW




            
            # elif robotMode == RobotMode.DROP_ITEM:
            #     if shelfMarkersRB[TARGET_ROW_INDEX] != None:
            #         shelfB = shelfMarkersRB[TARGET_ROW_INDEX][1]
            #         aligned = steerToBearing(shelfB, BEARING_LIMIT, board)
            #         if aligned:
            #             direction = bayTurn(TARGET_BAY)
            #             if direction == 'right':
            #                 turnAngle_encoder(board, -90, 75)
            #                 sleep(1)
            #             elif direction == 'left':
            #                 turnAngle_encoder(board, 90, 75)
            #                 sleep(1)
            #             if TARGET_BAY_HEIGHT == 0:
            #                 level_1()
            #                 sleep(1)
            #             elif TARGET_BAY_HEIGHT == 1:
            #                 level_2()
            #                 sleep(1)
            #             elif TARGET_BAY_HEIGHT == 2:
            #                 level_3()
            #                 sleep(1)
            #             drive_distance(board, 0.1, 50)
            #             sleep(1)
            #             board.motor_stop(board.ALL)
            #             sleep(1)
            #             open_grabber()
            #             sleep(1)
            #             drive_distance(board, -0.1, 50)
            #             sleep(1)
            #             direction = bayTurn(TARGET_BAY)
            #             if direction == 'right': angle = 90
            #             elif direction == 'left': angle = -90
            #             turnAngle_encoder(board, angle, 75)
            #             sleep(1)
            #             aligned = steerToBearing(shelfB, BEARING_LIMIT, board)
            #             if aligned:
            #                 robotMode = RobotMode.EXIT_ROW
            

            elif robotMode == RobotMode.EXIT_ROW:
                if led_flag == False:
                    sleep(0.1)
                    toggle_led('r') # red off
                    sleep(0.1)
                    toggle_led('y') # yellow on
                    led_flag = True
                TARGET_ROW_INDEX = rowIndex(TARGET_BAY)
                shelfMarkerRB = shelfMarkersRB[TARGET_ROW_INDEX]
                if shelfMarkerRB != None:
                    shelfB = shelfMarkerRB[1]
                    shelfD = shelfMarkerRB[0]
                    if abs(shelfB) < BEARING_LIMIT:
                        print("i am aligned with the shelf to exit")
                        if shelfD < STATION_ROW_DIST:
                            sleep(0.1)
                            drive_distance(board, -(STATION_ROW_DIST - shelfD), 75)
                            sleep(1)
                            board.motor_stop(board.ALL)
                            led_flag = False
                            robotMode = RobotMode.FIND_ORIGIN
                        else:
                            board.motor_stop(board.ALL)
                            print("i am in the else")
                            led_flag = False
                            robotMode = RobotMode.FIND_ORIGIN
                    else:
                        if shelfB > 0:
                            turnSearchDirection(50, board, 'L')
                        elif shelfB < 0:
                            turnSearchDirection(50, board, 'R')
                else:
                    turnSearch(50, board)

            
            elif robotMode == RobotMode.FIND_ORIGIN:
                turnAngle_encoder(board, 90, 50)
                distDrive = 0.3*(TARGET_ROW_INDEX-2)*-1
                print("distDrive is", distDrive)
                drive_distance(board, distDrive, 75)
                sleep(2)
                board.motor_stop(board.ALL)
                sleep(1)
                usD = trigger_ping()/100
                sleep(1)
                if usD > 0.2:
                    while usD > 0.2:
                        board.motor_movement([board.M1], board.CCW, 75)
                        board.motor_movement([board.M2], board.CW,  75)
                        usD = trigger_ping()/100  
                    board.motor_stop(board.ALL)
                elif usD < 0.2:
                    while usD < 0.2:
                        board.motor_movement([board.M1], board.CW, 75)
                        board.motor_movement([board.M2], board.CCW,  75)
                        usD = trigger_ping()/100  
                    board.motor_stop(board.ALL)
                
                sleep(2)
                turnAngle_encoder(board, 90, 60)
                sleep(1)
                board.motor_stop(board.ALL)
                sleep(1)
                usD = trigger_ping()/100
                sleep(1)
                if usD > 0.25:
                    while usD > 0.25:
                        board.motor_movement([board.M1], board.CCW, 75)
                        board.motor_movement([board.M2], board.CW,  75)
                        usD = trigger_ping()/100  
                    board.motor_stop(board.ALL)
                elif usD < 0.25:
                    while usD < 0.25:
                        board.motor_movement([board.M1], board.CW, 75)
                        board.motor_movement([board.M2], board.CCW,  75)
                        usD = trigger_ping()/100  
                    board.motor_stop(board.ALL)
                
                if ORDER_INDEX == 2:
                    robotMode = RobotMode.DEBUG_STOP
                else:
                    ORDER_INDEX += 1
                    robotMode = RobotMode.SEARCH_STATION
                        

            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('d'):
                plot_options['print_data'] = not plot_options['print_data']
            elif key == ord('l'):
                plot_options['plot_labels'] = not plot_options['plot_labels']
            elif key == ord('t'):
                plot_options['plot_trajectory'] = not plot_options['plot_trajectory']
            elif key == ord('c'):
                plot_options['plot_contours'] = not plot_options['plot_contours']
            elif key == ord('x'):
                plot_options['plot_exact_contours'] = not plot_options['plot_exact_contours']
            elif key == ord('a'):
                plot_options['plot_approximated_shapes'] = not plot_options['plot_approximated_shapes']
            elif key == ord('n'):
                plot_options['plot_centers'] = not plot_options['plot_centers']
            elif key == ord('r'):
                plot_options['plot_centre_reference'] = not plot_options['plot_centre_reference']



    except KeyboardInterrupt:
        print("\nShutting down...")
        board.motor_stop(board.ALL)
    except Exception as e:
       board.motor_stop(board.ALL)
       print(f"\nAn error occurred: {e}")
       traceback.print_exc()
    finally:
        board.motor_stop(board.ALL)
        # lgpio.gpio_write(h, SERVO_LEFT, 0)
        # lgpio.gpio_write(h, SERVO_RIGHT, 0)
        # lgpio.gpio_write(h, SERVO_GRAB, 0)
        # lgpio.gpiochip_close(h)
        camera.close()
        cv2.destroyAllWindows()