# -*- coding:utf-8 -*-

from __future__ import print_function
import sys
import os
from pynput import keyboard
from pynput.keyboard import Key
sys.path.append("../")

import time

from DFRobot_RaspberryPi_DC_Motor import THIS_BOARD_TYPE, DFRobot_DC_Motor_IIC as Board

from collection.collection import level_1, level_2, level_3, centre, open_grabber, close_grabber, readDistance

board = Board(1, 0x10)

# Global duty cycle variable
duty = 75
lDuty = 0.9*duty
duty_step = 2  # how much to increase/decrease with +/-

def board_detect():
    l = board.detecte()
    print("Board list conform:")
    print(l)

def print_board_status():
    if board.last_operate_status == board.STA_OK:
        print("board status: everything ok")
    elif board.last_operate_status == board.STA_ERR:
        print("board status: unexpected error")
    elif board.last_operate_status == board.STA_ERR_DEVICE_NOT_DETECTED:
        print("board status: device not detected")
    elif board.last_operate_status == board.STA_ERR_PARAMETER:
        print("board status: parameter error, last operate no effective")
    elif board.last_operate_status == board.STA_ERR_SOFT_VERSION:
        print("board status: unsupported board firmware version")

# def drive_distance(board, distance_m, speed_pct,
#                    wheel_diameter_mm=30,
#                    gear_ratio=50,
#                    slow_down_window_frac=0.55,     # taper starts at ~55% of target
#                    final_window_frac=0.18,          # creep in last ~18% of target
#                    min_slowdown_m=0.12,             # >= 12 cm taper floor
#                    min_final_m=0.030,               # >= 3 cm creep floor
#                    min_speed_pct=10.0,
#                    poll_dt=0.01, watchdog_s=1.5,
#                    right_scale_fwd=1, right_scale_rev=1,
#                    accel_time=0.20,
#                    brake_ms=120, brake_pct=18,
#                    # >>> Calibrate THIS <<< : s_true = comp_k * s_enc + comp_b
#                    comp_k=1, comp_b=0.0,
#                    debug=True):
#     """
#     Blocking straight drive using true-distance control:
#       s_true = comp_k * s_enc + comp_b
#     Windows scale with target so 0.10 m and 0.30 m behave proportionally.
#     Returns encoder distance s_enc (meters).
#     """
#     import math
#     from time import sleep, monotonic

#     true_target = abs(float(distance_m))
#     if true_target < 1e-6:
#         board.motor_stop(board.ALL)
#         return 0.0
#     direction = 1 if distance_m > 0 else -1

#     # Encoders configured so get_encoder_speed returns wheel RPM
#     board.set_encoder_enable([board.M1, board.M2])
#     board.set_encoder_reduction_ratio([board.M1, board.M2], int(gear_ratio))

#     circ = math.pi * (float(wheel_diameter_mm) / 1000.0)  # meters / rev

#     # Scale windows with the target (with floors so short moves still taper)
#     slow_down_window_m = max(min_slowdown_m, slow_down_window_frac * true_target)
#     final_window_m     = max(min_final_m,   final_window_frac   * true_target)

#     speed_pct = float(max(0.0, min(100.0, speed_pct)))
#     min_speed_pct = float(max(0.0, min(min_speed_pct, speed_pct)))

#     def cmd(v):
#         if direction == 1:
#             vR = v * right_scale_fwd
#             board.motor_movement([board.M1], board.CCW, v)
#             board.motor_movement([board.M2], board.CW,  vR)
#         else:
#             vR = v * right_scale_rev
#             board.motor_movement([board.M1], board.CW,  v)
#             board.motor_movement([board.M2], board.CCW, vR)

#     # soft start
#     t0 = monotonic()
#     cmd(min_speed_pct)

#     sL = sR = 0.0
#     t_prev = monotonic()
#     s_last_change_t = t_prev
#     dbg_t_last = t_prev

#     phase = "cruise"

#     try:
#         while True:
#             sleep(poll_dt)
#             t_now = monotonic()
#             dt = t_now - t_prev
#             t_prev = t_now

#             # accel ramp
#             if accel_time > 0:
#                 ramp = min(1.0, (t_now - t0) / accel_time)
#                 v_cmd = min_speed_pct + (speed_pct - min_speed_pct) * ramp
#             else:
#                 v_cmd = speed_pct

#             # encoders -> distance
#             rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
#             revL = abs(rpmL) * dt / 60.0 * 2
#             revR = abs(rpmR) * dt / 60.0 * 2

#             sL += revL * circ
#             sR += revR * circ
#             s_enc  = 0.5 * (sL + sR)
#             s_true = comp_k * s_enc + comp_b

#             # watchdog (detect no movement)
#             if (revL + revR) > 0:
#                 s_last_change_t = t_now
#             elif (t_now - s_last_change_t) > watchdog_s:
#                 break

#             remaining = true_target - s_true
#             if remaining <= 0:
#                 phase = "stop"
#                 break

#            # taper using TRUE meters
#             # if remaining < final_window_m:
#             #     phase = "creep"
#             #     cmd(min_speed_pct)
#             # elif remaining < slow_down_window_m:
#             #     phase = "slow"
#             #     scaled = v_cmd * (remaining / max(1e-6, slow_down_window_m))
#             #     cmd_speed = max(min_speed_pct, scaled)
#             #     cmd(cmd_speed)
#             # else:
#             phase = "cruise"
#             cmd(v_cmd)

#             # light debug print at ~10 Hz
#             if debug and (t_now - dbg_t_last) > 0.10:
#                 print(f"[drive] tgt={true_target:.3f}  s_enc={s_enc:.3f}  s_true={s_true:.3f}  rem={remaining:.3f}  phase={phase}")
#                 dbg_t_last = t_now

#     finally:
#         board.motor_stop(board.ALL)

#     # gentle brake (skip for *very* short moves to avoid undershoot)
#     if brake_ms > 0 and brake_pct > 0 and true_target > 0.12:
#         if direction == 1:
#             board.motor_movement([board.M1], board.CW,  brake_pct)
#             board.motor_movement([board.M2], board.CCW, brake_pct * right_scale_rev)
#         else:
#             board.motor_movement([board.M1], board.CCW, brake_pct)
#             board.motor_movement([board.M2], board.CW,  brake_pct * right_scale_fwd)
#         sleep(brake_ms / 1000.0)
#         board.motor_stop(board.ALL)

#     return 0.5 * (sL + sR)  # s_enc

def drive_distance(board, distance_m, speed_pct,
                   wheel_diameter_mm=30,
                   gear_ratio=50,
                   poll_dt=0.01, watchdog_s=1.5,
                   right_scale_fwd=1.0, right_scale_rev=1.0,
                   # encoder scaling: s_true = comp_k * s_enc + comp_b
                   comp_k=1.0, comp_b=0.0,
                   # If your HAT under/over-reports revs, tweak this (e.g., 2.0 if needed)
                   rev_scale=1.0,
                   debug=True):
    """
    Pure encoder-based straight drive:
      - Constant PWM at `speed_pct` (no ramp, no slowdown, no brake)
      - Stop exactly when s_true >= target, where s_true = comp_k * s_enc + comp_b
      - Returns s_enc (meters) for the move.

    Notes:
      - `rev_scale` lets you compensate if your get_encoder_speed() is off by a fixed factor.
        Keep it at 1.0 unless you *know* you need something else.
    """
    import math
    from time import sleep, monotonic

    true_target = abs(float(distance_m))
    if true_target < 1e-6:
        board.motor_stop(board.ALL)
        return 0.0

    direction = 1 if distance_m > 0 else -1

    # Configure encoders so get_encoder_speed returns *wheel* RPM
    board.set_encoder_enable([board.M1, board.M2])
    board.set_encoder_reduction_ratio([board.M1, board.M2], int(50))

    # Geometry
    circ = math.pi * (float(wheel_diameter_mm) / 1000.0)  # meters per wheel revolution

    # Clamp speed
    v_cmd = float(max(0.0, min(100.0, speed_pct)))

    # Motor command helper (constant PWM)
    def cmd_const(v):
        if direction == 1:
            vR = v * right_scale_fwd
            board.motor_movement([board.M1], board.CCW, v)
            board.motor_movement([board.M2], board.CW,  vR)
        else:
            vR = v * right_scale_rev
            board.motor_movement([board.M1], board.CW,  v)
            board.motor_movement([board.M2], board.CCW, vR)

    # Start moving immediately at constant PWM
    cmd_const(v_cmd)

    sL = sR = 0.0
    t_prev = monotonic()
    s_last_change_t = t_prev
    dbg_t_last = t_prev
    initialTime = monotonic()

    try:
        while True:
            sleep(poll_dt)
            t_now = monotonic()
            dt = t_now - t_prev
            t_prev = t_now

            # Read wheel RPMs and integrate distance
            rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])

            # Convert RPM -> revolutions in this dt; allow an overall rev_scale if needed
            revL = abs(rpmL) * dt / 60.0 * rev_scale
            revR = abs(rpmR) * dt / 60.0 * rev_scale

            sL += revL * circ
            sR += revR * circ 
            s_enc  = 0.5 * (sL + sR)              # encoder-averaged distance (meters)
            s_true = comp_k * s_enc + comp_b      # calibrated true distance (meters)

            # Watchdog (no movement)
            if (revL + revR) > 0:
                s_last_change_t = t_now
            elif (t_now - s_last_change_t) > watchdog_s:
                if debug:
                    print("[drive/raw] watchdog timeout; stopping")
                break

            remaining = true_target - s_true
            if debug and (t_now - dbg_t_last) > 0.10:
                print(f'''[drive/raw] tgt={true_target:.3f}  s_enc={s_enc:.3f}  s_true={s_true:.3f}  rem={remaining:.3f}
                      rpmL={rpmL}  rpmR={rpmR}''')
                dbg_t_last = t_now

            # Pure threshold stop on true distance
            if remaining <= 0.0:
                break

    finally:
        finalTime = monotonic()
        print("time elapsed is", finalTime-initialTime)
        board.motor_stop(board.ALL)

    # Return encoder distance (meters) for the move
    return 0.5 * (sL + sR)


def drive_distance_j(board, distance_m, speed_pct,
                   wheel_diameter_mm=30,
                   gear_ratio=50,
                   poll_dt=0.015, watchdog_s=1.5,
                   right_scale_fwd=1.0, right_scale_rev=1.0,
                   comp_k=1.0, comp_b=0.0,      # s_true = comp_k*f(s_enc)+comp_b
                   steer_gain=0.12, steer_max=2.0,
                   stop_lead_m=0.020,           # creep window (m of true distance)
                   creep_pct=8.0,
                   debug=True):
    """
    Straight drive using encoder integration + nonlinear calibration:
      s_true = f(s_enc) via piecewise-linear LUT.

    The LUT is built from your latest s_enc_final -> target_true pairs.
    """
    import math
    from time import sleep, monotonic

    # --- UPDATED NONLINEAR LUT: encoder_m -> true_m ------------------------
    # Points derived from your logs (s_enc_final mapped to the intended true distance)
    enc_to_true_lut = [
        (0.000, 0.000),
        (0.024, 0.105),
        (0.026, 0.110),   # 11 cm  ← new
        (0.034, 0.130),   # 13 cm
        (0.046, 0.140),   # 14 cm
        (0.100, 0.200),   # 20 cm
        (0.1915, 0.3015), # ~30.15 cm
        (0.2830, 0.4025), # ~40.25 cm
        (0.3750, 0.5000), # 50 cm
        (0.4635, 0.5990), # ~59.9 cm
        (0.5535, 0.7000), # 70 cm
        (0.824, 1.0500),
    ]




    # -----------------------------------------------------------------------

    def _enc_to_true(s_enc):
        """Piecewise-linear interpolation of s_true from s_enc using LUT."""
        pts = sorted(enc_to_true_lut, key=lambda p: p[0])
        x = float(s_enc)
        if x <= pts[0][0]:
            x0, y0 = pts[0]; x1, y1 = pts[1]
            t = (x - x0) / max(1e-9, (x1 - x0))
            return y0 + t * (y1 - y0)
        if x >= pts[-1][0]:
            x0, y0 = pts[-2]; x1, y1 = pts[-1]
            t = (x - x0) / max(1e-9, (x1 - x0))
            return y0 + t * (y1 - y0)
        for i in range(len(pts) - 1):
            x0, y0 = pts[i]; x1, y1 = pts[i + 1]
            if x0 <= x <= x1:
                t = (x - x0) / max(1e-9, (x1 - x0))
                return y0 + t * (y1 - y0)
        return x  # shouldn't happen

    # --- setup -------------------------------------------------------------
    want = float(distance_m)
    direction = 1 if want >= 0 else -1
    want_abs = abs(want)
    if want_abs < 1e-6:
        board.motor_stop(board.ALL); return 0.0

    # Slightly gentler creep for very short moves (<= 0.15 m)
    local_stop_lead = stop_lead_m
    local_creep_pct = creep_pct
    if want_abs <= 0.15:
        local_stop_lead = max(stop_lead_m, 0.025)
        local_creep_pct = min(creep_pct, 6.0)

    board.set_encoder_enable([board.M1, board.M2])
    board.set_encoder_reduction_ratio([board.M1, board.M2], int(gear_ratio))

    circ = math.pi * (float(wheel_diameter_mm) / 1000.0)  # m / rev

    v_cmd = float(max(0.0, min(100.0, speed_pct)))
    creep_cmd = float(max(0.0, min(v_cmd, local_creep_pct)))

    def _drive(pct, biasR=0.0):
        b = max(-steer_max, min(steer_max, biasR))
        vR = max(0.0, min(100.0, pct + b))
        if direction == 1:
            board.motor_movement([board.M1], board.CCW, pct)
            board.motor_movement([board.M2], board.CW,  vR)
        else:
            board.motor_movement([board.M1], board.CW,  pct)
            board.motor_movement([board.M2], board.CCW, vR)

    _drive(v_cmd, 0.0)

    sL = sR = 0.0
    t_prev = monotonic()
    s_last_change_t = t_prev
    dbg_t_last = t_prev

    try:
        # ---- CRUISE -------------------------------------------------------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
            revL = abs(rpmL) * dt / 60.0
            revR = abs(rpmR) * dt / 60.0

            moved = (revL + revR) > 0.0
            if moved:
                s_last_change_t = t_now
            elif (t_now - s_last_change_t) > watchdog_s:
                if debug: print("[drive] watchdog timeout; stopping")
                break

            dL = revL * circ; dR = revR * circ
            sL += dL; sR += dR
            s_enc  = 0.5 * (sL + sR)
            s_true = comp_k * _enc_to_true(s_enc) + comp_b

            # steering trim (keep straight)
            dErr = sL - sR
            corrR = -steer_gain * dErr

            remaining_true = want_abs - s_true
            sdot = (dL + dR) * 0.5 / max(dt, 1e-6)

            if debug and (t_now - dbg_t_last) > 0.10:
                print(f"[drive/raw] tgt={want_abs:.3f}  s_enc={s_enc:.3f}  s_true={s_true:.3f}  "
                      f"rem={remaining_true:.3f}  dt={dt*1000:.1f}ms  rpmL={int(rpmL)} rpmR={int(rpmR)}  "
                      f"sdot={sdot:.3f} m/s  dErr={dErr:+.4f} m  corrR={corrR:+.1f}")
                dbg_t_last = t_now

            if remaining_true <= local_stop_lead:
                break

            _drive(v_cmd, corrR)

        # ---- CREEP --------------------------------------------------------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
            revL = abs(rpmL) * dt / 60.0
            revR = abs(rpmR) * dt / 60.0

            dL = revL * circ; dR = revR * circ
            sL += dL; sR += dR
            s_enc  = 0.5 * (sL + sR)
            s_true = comp_k * _enc_to_true(s_enc) + comp_b
            remaining_true = want_abs - s_true

            dErr = sL - sR
            corrR = -steer_gain * dErr
            _drive(creep_cmd, corrR)

            if debug:
                print(f"[drive/creep] s_true={s_true:.3f}  rem={remaining_true:.3f}  corrR={corrR:+.1f}")

            if remaining_true <= 0.0:
                break

    finally:
        if debug:
            s_enc_final = 0.5 * (sL + sR)
            print(f"[drive/done] s_enc_final={s_enc_final:.3f} m  (use this with your tape-measure result to refine the LUT)")
        board.motor_stop(board.ALL)

    return 0.5 * (sL + sR)










def turnAngle_encoder(board,
                      angle_deg,
                      speed_pct,
                      wheel_diameter_mm=30,
                      wheelbase_mm=170,
                      gear_ratio=50,
                      poll_dt=0.015,
                      watchdog_s=1.5,
                      # --- Tuned from "function test 4" ---
                      # Interpolated between 90° and 180° for each sign
                      b_pos_90=1.380,    # was 1.362 → +90 was +2° (reduce angle)
                      b_pos_180=1.175,   # was 1.160 → +180 was −5° (increase angle)
                      b_neg_90=1.415,    # was 1.386 → −90 was −7° (reduce |angle|)
                      b_neg_180=1.135,   # was 1.131 → −180 was −1° (tiny trim)
                      creep_pct=4.0,     # gentle tail to limit slip
                      steer_trim=0.0,
                      CTRL_LATENCY_S=0.075,
                      A_BRAKE_MPS2=1.0,
                      # Small turns: stop a touch earlier; Large turns: carry a touch longer
                      lead_bias_deg_small=1.4,   # was 1.2
                      lead_bias_deg_large=0.50,  # was 0.60
                      debug=False):
    """
    Spin-in-place using straight-drive LUT + angle/sign-dependent effective wheelbase.
    Scales tuned from your 'function test 4' results. We linearly interpolate b_eff
    between 90° and 180° by |angle| for each spin direction.
    """
    import math
    from time import sleep, monotonic
    #TODO: TUNING ANGLE
    if angle_deg == 90:
        print("90")
        angle_deg = angle_deg * 0.95
    elif angle_deg == -90:
        print("-90")
        angle_deg = angle_deg * 0.9
    elif angle_deg == 180:
        print("180")
        angle_deg = angle_deg * 0.98
    elif angle_deg == -180:
        print("-180")
        angle_deg = angle_deg * 1.02

    # --- straight-drive LUT (encoder_m -> true_m) ---
    enc_to_true_lut = [
        (0.000, 0.000),
        (0.025, 0.110),
        (0.034, 0.130),
        (0.046, 0.140),
        (0.100, 0.200),
        (0.1915, 0.3015),
        (0.2830, 0.4025),
        (0.3750, 0.5000),
        (0.4635, 0.5990),
        (0.5535, 0.7000),
        (0.8240, 1.0500),
    ]

    def _enc_to_true(x):
        pts = enc_to_true_lut
        x = float(x)
        if x <= pts[0][0]:
            x0, y0 = pts[0]; x1, y1 = pts[1]
            t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t*(y1 - y0)
        if x >= pts[-1][0]:
            x0, y0 = pts[-2]; x1, y1 = pts[-1]
            t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t*(y1 - y0)
        for i in range(len(pts)-1):
            x0, y0 = pts[i]; x1, y1 = pts[i+1]
            if x0 <= x <= x1:
                t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t*(y1 - y0)
        return x

    def predicted_stop_lead_m(sdot_mps, floor=0.015, extra_m=0.0):
        sdot = max(0.0, float(sdot_mps))
        stop_pred = CTRL_LATENCY_S*sdot + (sdot*sdot)/max(2.0*A_BRAKE_MPS2, 1e-6)
        return max(floor, stop_pred + extra_m)

    ang_abs = abs(float(angle_deg))
    if ang_abs <= 90.0:
        extra_lead_deg = lead_bias_deg_small
    elif ang_abs >= 180.0:
        extra_lead_deg = lead_bias_deg_large
    else:
        t = (ang_abs - 90.0) / 90.0
        extra_lead_deg = lead_bias_deg_small + t*(lead_bias_deg_large - lead_bias_deg_small)

    def interp(a, a0, a1, y0, y1):
        a = float(a)
        if a <= a0: return y0
        if a >= a1: return y1
        t = (a - a0) / (a1 - a0)
        return y0 + t*(y1 - y0)

    # angle- & sign-dependent effective wheelbase scale
    if angle_deg >= 0:
        b_scale = interp(ang_abs, 90.0, 180.0, b_pos_90, b_pos_180)
    else:
        b_scale = interp(ang_abs, 90.0, 180.0, b_neg_90, b_neg_180)

    # --- setup hardware ---
    board.set_encoder_enable([board.M1, board.M2])
    board.set_encoder_reduction_ratio([board.M1, board.M2], int(gear_ratio))

    b_geom = wheelbase_mm / 1000.0
    b_eff  = b_geom * b_scale

    circ = math.pi * (wheel_diameter_mm / 1000.0)
    theta_goal = math.radians(angle_deg)

    sign = 1.0 if theta_goal >= 0.0 else -1.0
    oL = board.CW  if sign > 0 else board.CCW
    oR = board.CW  if sign > 0 else board.CCW

    v_cmd     = float(max(0.0, min(100.0, speed_pct)))
    creep_cmd = max(2.0, min(creep_pct, v_cmd))

    # start spin
    board.motor_movement([board.M1], oL, v_cmd + 0.0)
    board.motor_movement([board.M2], oR, v_cmd + steer_trim)

    sL_enc = sR_enc = 0.0
    t_prev = monotonic()
    s_last_change_t = t_prev
    ema_sdot = 0.0
    alpha = 0.2
    dbg_t_last = t_prev

    def read_step(dt):
        rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
        revL = abs(rpmL) * dt / 60.0
        revR = abs(rpmR) * dt / 60.0
        sgnL = -sign
        sgnR = +sign
        return sgnL*revL*circ, sgnR*revR*circ, rpmL, rpmR

    try:
        # -------- CRUISE --------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            dL, dR, rpmL, rpmR = read_step(dt)
            moved = (abs(dL) + abs(dR)) > 0.0
            if moved: s_last_change_t = t_now
            elif (t_now - s_last_change_t) > watchdog_s:
                if debug: print("[turn] watchdog timeout; stopping"); break

            sL_enc += dL; sR_enc += dR

            sL_true = math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)
            sR_true = math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)

            theta_true = (sR_true - sL_true) / b_eff
            theta_rem  = theta_goal - theta_true

            sdot     = 0.5*(abs(dL) + abs(dR)) / max(dt, 1e-6)
            ema_sdot = (1 - alpha)*ema_sdot + alpha*sdot

            if debug and (t_now - dbg_t_last) > 0.10:
                print(f"[turn/raw] tgt={math.degrees(theta_goal):.1f}°  θ={math.degrees(theta_true):.1f}°  "
                      f"rem={math.degrees(theta_rem):.1f}°  sdot={sdot:.3f} m/s  "
                      f"rpmL={int(rpmL)} rpmR={int(rpmR)}  b_eff={b_eff:.3f} m")
                dbg_t_last = t_now

            lead_m     = predicted_stop_lead_m(ema_sdot,
                                               floor=0.015,
                                               extra_m=(extra_lead_deg*math.pi/180.0) * (b_eff/2.0))
            lead_theta = 2.0 * lead_m / b_eff

            if abs(theta_rem) <= lead_theta:
                break

            board.motor_movement([board.M1], oL, v_cmd + 0.0)
            board.motor_movement([board.M2], oR, v_cmd + steer_trim)

        # -------- CREEP --------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            dL, dR, rpmL, rpmR = read_step(dt)
            sL_enc += dL; sR_enc += dR
            sL_true = math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)
            sR_true = math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)
            theta_true = (sR_true - sL_true) / b_eff
            theta_rem  = theta_goal - theta_true

            board.motor_movement([board.M1], oL, creep_cmd + 0.0)
            board.motor_movement([board.M2], oR, creep_cmd + steer_trim)

            if debug:
                print(f"[turn/creep] θ={math.degrees(theta_true):.2f}°  rem={math.degrees(theta_rem):.2f}°  b_eff={b_eff:.3f} m")

            if (theta_goal >= 0 and theta_true >= theta_goal) or (theta_goal < 0 and theta_true <= theta_goal):
                break

    finally:
        board.motor_stop(board.ALL)
        if debug:
            theta_meas_deg = math.degrees(
                (math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)
                 - math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)) / b_eff
            )
            print(f"[turn/done] θ_meas≈{theta_meas_deg:.2f}°  (angle-adaptive b_eff active)")

    return math.degrees(
        (math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)
         - math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)) / b_eff
    )




def handRPM():
    import math
    from time import sleep, monotonic
    poll_dt = 0.01
    board.set_encoder_enable([board.M1, board.M2])
    board.set_encoder_reduction_ratio([board.M1, board.M2], int(50))
    circ = math.pi*(30/1000)

    t0 = monotonic()
    sL = sR = 0.0
    t_prev = monotonic()
    s_last_change_t = t_prev
    dbg_t_last = t_prev
    while True:
        sleep(poll_dt)
        t_now = monotonic()
        dt = t_now - t_prev
        t_prev = t_now

        # encoders -> distance
        rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
        revL = abs(rpmL) * dt / 60.0
        revR = abs(rpmR) * dt / 60.0

        sL += revL * circ
        sR += revR * circ
        s_enc  = 0.5 * (sL + sR)

        print("DEBUGGING:")
        print("revL", revL)
        print("revR", revR)
        print("sL", sL)
        print("sR", sR)
        print("s_enc", s_enc)

def on_key_release(key):
    board.motor_stop(board.ALL)

def on_key_pressed(key):
    global duty
    global lDuty

    if key == Key.right:
        print(f"Right key pressed at duty {duty}%")
        board.motor_movement([board.M1], board.CW, duty)
        board.motor_movement([board.M2], board.CW, duty)

    elif key == Key.left:
        print(f"Left key pressed at duty {duty}%")
        board.motor_movement([board.M1], board.CCW, duty)
        board.motor_movement([board.M2], board.CCW, duty)

    elif key == Key.up:
        print(f"Up key pressed at duty {duty}%")
        board.motor_movement([board.M1], board.CCW, duty)
        board.motor_movement([board.M2], board.CW, lDuty)

    elif key == Key.down:
        print(f"Down key pressed at duty {duty}%")
        board.motor_movement([board.M1], board.CW, duty)
        board.motor_movement([board.M2], board.CCW, lDuty)

    elif key == Key.esc:
        print("ESC pressed: stopping motors for 3s")
        board.motor_stop(board.ALL)
        time.sleep(3)

    elif key == Key.delete:
        print("Delete pressed: exiting in 3s")
        time.sleep(3)
        listener.stop()

    elif hasattr(key, 'char') and key.char=='o':
        open_grabber()
    
    elif hasattr(key, 'char') and key.char == 'c':
        close_grabber()

    elif hasattr(key, 'char') and key.char == 'b':
        level_1()
        
    elif hasattr(key, 'char') and key.char == 'n':
        level_2()

    elif hasattr(key, 'char') and key.char == 'm':
        level_3()
    elif hasattr(key, 'char') and key.char =='h':
        centre()
    
    

    # Adjust duty with + and -
    elif hasattr(key, 'char') and key.char == '+':
        duty = min(100, duty + duty_step)
        lDuty = 0.9*duty
        print(f"Duty increased to {duty}%")

    elif hasattr(key, 'char') and key.char == '-':
        duty = max(0, duty - duty_step)
        lDuty = 0.9*duty
        print(f"Duty decreased to {duty}%")

if __name__ == "__main__":
    print("Starting...")

    #initServos()
    #centre()
    

    # with keyboard.Listener(on_press=on_key_pressed, on_release=on_key_release) as listener:
    #     listener.join()

    board_detect()

    while board.begin() != board.STA_OK:
        print_board_status()
        print("board begin failed")
        time.sleep(2)

    print("board begin success")
    board.set_encoder_enable(board.ALL)
    board.set_encoder_reduction_ratio(board.ALL, 50)
    board.set_moter_pwm_frequency(2000)

    level_3()

    #drive_distance(board, 0.1, 75)
    #handRPM()
    #drive_distance_j(board, 1, 75)
    #drive_distance_predictive(board, 0.3, 75)
    turnAngle_encoder(board, 90, 60)
    time.sleep(2)
    turnAngle_encoder(board, -90, 60)
    time.sleep(2)
    turnAngle_encoder(board, 180, 60)
    time.sleep(2)
    turnAngle_encoder(board, -180, 60)
    time.sleep(2)
    board.motor_stop(board.ALL)

    # Example: run 0.30 m at 75% duty, with a first-guess PPR and no wraps
    # drive_distance_ticks(board, 0.10, 75,
    #                  wheel_diameter_mm=30,
    #                  pulses_per_rev_wheel=2200,  # <-- put your real value here
    #                  counter_modulus=None,       # or 65536 if your counter wraps at 16-bit
    #                  kL=1.0, kR=1.0,
    #                  comp_k=1.0, comp_b=0.0,
    #                  debug=True)


    