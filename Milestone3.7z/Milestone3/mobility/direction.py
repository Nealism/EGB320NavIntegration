from time import sleep, monotonic, time
import math

WHEEL_DIAMETER_MM = 30
TRACK_WIDTH_MM = 185

def turnAngle_encoder(board,
                      angle_deg,
                      speed_pct,
                      wheel_diameter_mm=30,
                      wheelbase_mm=170,
                      gear_ratio=50,
                      poll_dt=0.015,
                      watchdog_s=1.5,
                      # --- Tuned from "function test 4" ---
                      # Interpolated between 90° and 180° for each sign
                      b_pos_90=1.380,    # was 1.362 → +90 was +2° (reduce angle)
                      b_pos_180=1.175,   # was 1.160 → +180 was −5° (increase angle)
                      b_neg_90=1.415,    # was 1.386 → −90 was −7° (reduce |angle|)
                      b_neg_180=1.135,   # was 1.131 → −180 was −1° (tiny trim)
                      creep_pct=4.0,     # gentle tail to limit slip
                      steer_trim=0.0,
                      CTRL_LATENCY_S=0.075,
                      A_BRAKE_MPS2=1.0,
                      # Small turns: stop a touch earlier; Large turns: carry a touch longer
                      lead_bias_deg_small=1.4,   # was 1.2
                      lead_bias_deg_large=0.50,  # was 0.60
                      debug=False):
    """
    Spin-in-place using straight-drive LUT + angle/sign-dependent effective wheelbase.
    Scales tuned from your 'function test 4' results. We linearly interpolate b_eff
    between 90° and 180° by |angle| for each spin direction.
    """
    import math
    from time import sleep, monotonic
    #TODO: TUNING ANGLE
    if angle_deg == 90:
        print("90")
        angle_deg = angle_deg * 0.95
    elif angle_deg == -90:
        print("-90")
        angle_deg = angle_deg * 0.95
    elif angle_deg == 180:
        print("180")
        angle_deg = angle_deg * 0.96
    elif angle_deg == -180:
        print("-180")
        angle_deg = angle_deg * 1

    # --- straight-drive LUT (encoder_m -> true_m) ---
    enc_to_true_lut = [
        (0.000, 0.000),
        (0.025, 0.110),
        (0.034, 0.130),
        (0.046, 0.140),
        (0.100, 0.200),
        (0.1915, 0.3015),
        (0.2830, 0.4025),
        (0.3750, 0.5000),
        (0.4635, 0.5990),
        (0.5535, 0.7000),
        (0.8240, 1.0500),
    ]

    def _enc_to_true(x):
        pts = enc_to_true_lut
        x = float(x)
        if x <= pts[0][0]:
            x0, y0 = pts[0]; x1, y1 = pts[1]
            t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t*(y1 - y0)
        if x >= pts[-1][0]:
            x0, y0 = pts[-2]; x1, y1 = pts[-1]
            t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t*(y1 - y0)
        for i in range(len(pts)-1):
            x0, y0 = pts[i]; x1, y1 = pts[i+1]
            if x0 <= x <= x1:
                t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t*(y1 - y0)
        return x

    def predicted_stop_lead_m(sdot_mps, floor=0.015, extra_m=0.0):
        sdot = max(0.0, float(sdot_mps))
        stop_pred = CTRL_LATENCY_S*sdot + (sdot*sdot)/max(2.0*A_BRAKE_MPS2, 1e-6)
        return max(floor, stop_pred + extra_m)

    ang_abs = abs(float(angle_deg))
    if ang_abs <= 90.0:
        extra_lead_deg = lead_bias_deg_small
    elif ang_abs >= 180.0:
        extra_lead_deg = lead_bias_deg_large
    else:
        t = (ang_abs - 90.0) / 90.0
        extra_lead_deg = lead_bias_deg_small + t*(lead_bias_deg_large - lead_bias_deg_small)

    def interp(a, a0, a1, y0, y1):
        a = float(a)
        if a <= a0: return y0
        if a >= a1: return y1
        t = (a - a0) / (a1 - a0)
        return y0 + t*(y1 - y0)

    # angle- & sign-dependent effective wheelbase scale
    if angle_deg >= 0:
        b_scale = interp(ang_abs, 90.0, 180.0, b_pos_90, b_pos_180)
    else:
        b_scale = interp(ang_abs, 90.0, 180.0, b_neg_90, b_neg_180)

    # --- setup hardware ---
    board.set_encoder_enable([board.M1, board.M2])
    board.set_encoder_reduction_ratio([board.M1, board.M2], int(gear_ratio))

    b_geom = wheelbase_mm / 1000.0
    b_eff  = b_geom * b_scale

    circ = math.pi * (wheel_diameter_mm / 1000.0)
    theta_goal = math.radians(angle_deg)

    sign = 1.0 if theta_goal >= 0.0 else -1.0
    oL = board.CW  if sign > 0 else board.CCW
    oR = board.CW  if sign > 0 else board.CCW

    v_cmd     = float(max(0.0, min(100.0, speed_pct)))
    creep_cmd = max(2.0, min(creep_pct, v_cmd))

    # start spin
    board.motor_movement([board.M1], oL, v_cmd + 0.0)
    board.motor_movement([board.M2], oR, v_cmd + steer_trim)

    sL_enc = sR_enc = 0.0
    t_prev = monotonic()
    s_last_change_t = t_prev
    ema_sdot = 0.0
    alpha = 0.2
    dbg_t_last = t_prev

    def read_step(dt):
        rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
        revL = abs(rpmL) * dt / 60.0
        revR = abs(rpmR) * dt / 60.0
        sgnL = -sign
        sgnR = +sign
        return sgnL*revL*circ, sgnR*revR*circ, rpmL, rpmR

    try:
        # -------- CRUISE --------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            dL, dR, rpmL, rpmR = read_step(dt)
            moved = (abs(dL) + abs(dR)) > 0.0
            if moved: s_last_change_t = t_now
            elif (t_now - s_last_change_t) > watchdog_s:
                if debug: print("[turn] watchdog timeout; stopping"); break

            sL_enc += dL; sR_enc += dR

            sL_true = math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)
            sR_true = math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)

            theta_true = (sR_true - sL_true) / b_eff
            theta_rem  = theta_goal - theta_true

            sdot     = 0.5*(abs(dL) + abs(dR)) / max(dt, 1e-6)
            ema_sdot = (1 - alpha)*ema_sdot + alpha*sdot

            if debug and (t_now - dbg_t_last) > 0.10:
                print(f"[turn/raw] tgt={math.degrees(theta_goal):.1f}°  θ={math.degrees(theta_true):.1f}°  "
                      f"rem={math.degrees(theta_rem):.1f}°  sdot={sdot:.3f} m/s  "
                      f"rpmL={int(rpmL)} rpmR={int(rpmR)}  b_eff={b_eff:.3f} m")
                dbg_t_last = t_now

            lead_m     = predicted_stop_lead_m(ema_sdot,
                                               floor=0.015,
                                               extra_m=(extra_lead_deg*math.pi/180.0) * (b_eff/2.0))
            lead_theta = 2.0 * lead_m / b_eff

            if abs(theta_rem) <= lead_theta:
                break

            board.motor_movement([board.M1], oL, v_cmd + 0.0)
            board.motor_movement([board.M2], oR, v_cmd + steer_trim)

        # -------- CREEP --------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            dL, dR, rpmL, rpmR = read_step(dt)
            sL_enc += dL; sR_enc += dR
            sL_true = math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)
            sR_true = math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)
            theta_true = (sR_true - sL_true) / b_eff
            theta_rem  = theta_goal - theta_true

            board.motor_movement([board.M1], oL, creep_cmd + 0.0)
            board.motor_movement([board.M2], oR, creep_cmd + steer_trim)

            if debug:
                print(f"[turn/creep] θ={math.degrees(theta_true):.2f}°  rem={math.degrees(theta_rem):.2f}°  b_eff={b_eff:.3f} m")

            if (theta_goal >= 0 and theta_true >= theta_goal) or (theta_goal < 0 and theta_true <= theta_goal):
                break

    finally:
        board.motor_stop(board.ALL)
        if debug:
            theta_meas_deg = math.degrees(
                (math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)
                 - math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)) / b_eff
            )
            print(f"[turn/done] θ_meas≈{theta_meas_deg:.2f}°  (angle-adaptive b_eff active)")

    return math.degrees(
        (math.copysign(_enc_to_true(abs(sR_enc)), sR_enc)
         - math.copysign(_enc_to_true(abs(sL_enc)), sL_enc)) / b_eff
    )


def drive_distance(board, distance_m, speed_pct,
                              wheel_diameter_mm=30,
                              gear_ratio=50,
                              poll_dt=0.015, watchdog_s=1,
                              comp_k=1.0, comp_b=0.0,      # s_true = comp_k*f(s_enc)+comp_b
                              steer_gain=0.12, steer_max=2.0,
                              stop_lead_floor_m=0.025,     # min creep window
                              creep_pct=8.0,
                              active_brake_pct=6.0,        # tiny reverse tap at the end (0=off)
                              lead_bias_m=0.010,           # extra cut-early distance (~1 cm)
                              debug=False):
    """
    Straight drive using encoder integration + nonlinear calibration (no voltage).
    """
    import math, time
    from time import sleep, monotonic

    enc_to_true_lut = [
        (0.000, 0.000),
        (0.025, 0.110),   # 11 cm
        (0.034, 0.130),   # 13 cm
        (0.046, 0.140),   # 14 cm
        (0.100, 0.200),   # 20 cm
        (0.1915, 0.3015), # ~30.15 cm
        (0.2830, 0.4025), # ~40.25 cm
        (0.3750, 0.5000), # 50 cm
        (0.4635, 0.5990), # ~59.9 cm
        (0.5535, 0.7000), # 70 cm
        (0.8240, 1.0500), # long run
    ]

    def _enc_to_true(s_enc):
        pts = enc_to_true_lut
        x = float(s_enc)
        if x <= pts[0][0]:
            x0, y0 = pts[0]; x1, y1 = pts[1]
            t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t * (y1 - y0)
        if x >= pts[-1][0]:
            x0, y0 = pts[-2]; x1, y1 = pts[-1]
            t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t * (y1 - y0)
        for i in range(len(pts) - 1):
            x0, y0 = pts[i]; x1, y1 = pts[i + 1]
            if x0 <= x <= x1:
                t = (x - x0) / max(1e-9, (x1 - x0)); return y0 + t * (y1 - y0)
        return x

    # --- Predictive stop model  ----------------------
    CTRL_LATENCY_S = 0.090     # was 0.060
    A_BRAKE_MPS2   = 1.2       # was 1.8 (smaller = softer braking -> larger lead)

    def predicted_stop_lead(sdot_mps, floor=0.015, extra=0.0):
        sdot = max(0.0, float(sdot_mps))
        stop_pred = CTRL_LATENCY_S * sdot + (sdot * sdot) / max(2.0 * A_BRAKE_MPS2, 1e-6)
        return max(floor, stop_pred + extra)

    # --- setup -------------------------------------------------------------------------
    want = float(distance_m)
    direction = 1 if want >= 0 else -1
    want_abs = abs(want)
    if want_abs < 1e-6:
        board.motor_stop(board.ALL); return 0.0

    # gentler creep for very short moves (<= 0.15 m)
    local_stop_floor = max(0.025, stop_lead_floor_m)
    local_creep_pct = min(creep_pct, 6.0) if want_abs <= 0.15 else min(creep_pct, 10.0)

    board.set_encoder_enable([board.M1, board.M2])
    board.set_encoder_reduction_ratio([board.M1, board.M2], int(gear_ratio))

    circ = math.pi * (float(wheel_diameter_mm) / 1000.0)  # m / wheel rev

    v_cmd_pct = float(max(0.0, min(100.0, speed_pct)))
    creep_cmd = float(max(0.0, min(v_cmd_pct, local_creep_pct)))

    def _drive(pct, biasR=0.0):
        # if not isinstance(pct, float):
        #     lPct = pct[0]
        #     rPct = pct[1]
        # else:
        #     lPct = pct
        #     rPct = pct
        if direction == 1:
            board.motor_movement([board.M1], board.CCW, pct)
            board.motor_movement([board.M2], board.CW,  pct)
        else:
            board.motor_movement([board.M1], board.CW,  pct)
            board.motor_movement([board.M2], board.CCW, pct)

    _drive(v_cmd_pct, 0.0)

    sL = sR = 0.0
    dL = dR = 0.0
    t_prev = monotonic()
    s_last_change_t = t_prev
    dbg_t_last = t_prev

    # simple EMA filter for dt & speed to blunt jitter
    ema_dt = poll_dt
    ema_sdot = 0.0
    alpha = 0.2
        # --- Watchdog for "no encoder motion" ---
    NO_MOVE_EPS_M = 0.0015                 # treat <1.5 mm as "no movement"
    NO_MOVE_TIMEOUT_S = float(watchdog_s)  # e.g., 1.0 s

    s_last_enc = 0.0
    s_last_change_t = t_prev               # already set above; start clock now


    try:
        # ---------------- CRUISE ----------------
        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now
            ema_dt = (1 - alpha) * ema_dt + alpha * dt

            rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])

            if rpmL is None: rpmL = 0.0
            if rpmR is None: rpmR = 0.0

            # rpm normaliser
            # if rpmL < 0.9*rpmR:
            #     rPct = rpmL/rpmR * speed_pct
            #     v_cmd_pct = [speed_pct, rPct]
            # elif rpmL > 1.1*rpmR:
            #     lPct = rpmR/rpmL * speed_pct
            #     v_cmd_pct = [lPct, speed_pct]


            revL = abs(rpmL) * dt / 60.0
            revR = abs(rpmR) * dt / 60.0


            dL = revL * circ; dR = revR * circ
            sL += dL; sR += dR
            s_enc  = 0.5 * (sL + sR)
            s_true = comp_k * _enc_to_true(s_enc) + comp_b

            # --- Watchdog based on actual encoder distance change ---
            s_enc_delta = (0.5 * (dL + dR))  # change this cycle in meters
            if s_enc_delta >= NO_MOVE_EPS_M:
                s_last_change_t = t_now
                s_last_enc = s_enc
            elif (t_now - s_last_change_t) > NO_MOVE_TIMEOUT_S:
                if debug:
                    print(f"[drive] watchdog: no encoder delta for {NO_MOVE_TIMEOUT_S:.2f}s — aborting")
                break

            dErr = sL - sR
            corrR = -steer_gain * dErr

            sdot = (dL + dR) * 0.5 / max(dt, 1e-6)
            ema_sdot = (1 - alpha) * ema_sdot + alpha * sdot

            remaining_true = want_abs - s_true

            if debug and (t_now - dbg_t_last) > 0.10:
                print(f"[drive/raw] tgt={want_abs:.3f}  s_enc={s_enc:.3f}  s_true={s_true:.3f}  "
                      f"rem={remaining_true:.3f}  dt={dt*1000:.1f}ms  rpmL={int(rpmL)} rpmR={int(rpmR)}  "
                      f"sdot={sdot:.3f} m/s  dErr={dErr:+.4f} m  corrR={corrR:+.1f}")
                dbg_t_last = t_now

            # dynamic stop lead; include fixed lead_bias_m to cancel small overshoot
            lead_needed = predicted_stop_lead(ema_sdot, floor=local_stop_floor, extra=lead_bias_m)

            if remaining_true <= lead_needed:
                break

            _drive(v_cmd_pct, corrR)

        # ---------------- CREEP ----------------
        target_residual = 0.004  # 4 mm
        sdot_creep = max(0.03, min(0.09, (2.0 * A_BRAKE_MPS2 * target_residual) ** 0.5))
        creep_cmd = min(creep_cmd, max(2.0, v_cmd_pct * (sdot_creep / 0.20)))
        creep_cmd = min(creep_cmd, 10.0)  # cap creep at 10%

        while True:
            sleep(poll_dt)
            t_now = monotonic(); dt = t_now - t_prev; t_prev = t_now

            rpmL, rpmR = board.get_encoder_speed([board.M1, board.M2])
            revL = abs(rpmL) * dt / 60.0
            revR = abs(rpmR) * dt / 60.0

            dL = revL * circ; dR = revR * circ
            sL += dL; sR += dR
            s_enc  = 0.5 * (sL + sR)
            s_true = comp_k * _enc_to_true(s_enc) + comp_b

            # --- Watchdog in CREEP too ---
            s_enc_delta = (0.5 * (dL + dR))
            if s_enc_delta >= NO_MOVE_EPS_M:
                s_last_change_t = t_now
                s_last_enc = s_enc
            elif (t_now - s_last_change_t) > NO_MOVE_TIMEOUT_S:
                if debug:
                    print(f"[drive] watchdog (creep): no encoder delta for {NO_MOVE_TIMEOUT_S:.2f}s — aborting")
                break



            remaining_true = want_abs - s_true

            dErr = sL - sR
            corrR = -steer_gain * dErr
            _drive(creep_cmd, corrR)

            if debug:
                print(f"[drive/creep] s_true={s_true:.3f}  rem={remaining_true:.3f}  corrR={corrR:+.1f}")

            if remaining_true <= 0.0:
                break

        # -------- Optional active brake (tiny reverse pulse) ---------------
        if active_brake_pct > 0.0:
            pct = max(0.0, min(12.0, float(active_brake_pct)))
            tap_s = 0.060  # ~60 ms
            if direction == 1:
                board.motor_movement([board.M1], board.CW,  pct)
                board.motor_movement([board.M2], board.CCW, pct)
            else:
                board.motor_movement([board.M1], board.CCW, pct)
                board.motor_movement([board.M2], board.CW,  pct)
            time.sleep(tap_s)

    finally:
        if debug:
            s_enc_final = 0.5 * (sL + sR)
            print(f"[drive/done] s_enc_final={s_enc_final:.3f} m  (use this with your tape-measure result to refine the LUT)")
        board.motor_stop(board.ALL)

    return 0.5 * (sL + sR)








def calcBayDistance(TARGET_BAY):
   TARGET_BAY = TARGET_BAY[1]
   reverseBayID = abs(TARGET_BAY-4)
   distance = (reverseBayID-1)*26 + 10
   return distance/100


def steerToBearing(b, limit, board):
    # inside deadband => stop + aligned
    if -limit <= b <= limit:
        board.motor_stop(board.ALL)
        return True

    # proportional spin speed, clipped
    k = 2.0  # try 1.5..3.0
    v = max(25, min(70, k * abs(b)))
    if b > 0:
        board.motor_movement([board.M1], board.CW,  60)
        board.motor_movement([board.M2], board.CW,  60)
    else:
        board.motor_movement([board.M1], board.CCW, 60)
        board.motor_movement([board.M2], board.CCW, 60)
    return False



def rowIndex(TARGET_BAY):
    TARGET_SHELF_INDEX = TARGET_BAY[0]
    if TARGET_SHELF_INDEX > -1 and TARGET_SHELF_INDEX < 2:
        TARGET_ROW_INDEX = 0
    elif TARGET_SHELF_INDEX > 1 and TARGET_SHELF_INDEX < 4:
        TARGET_ROW_INDEX = 1
    elif TARGET_SHELF_INDEX > 3 and TARGET_SHELF_INDEX < 6:
        TARGET_ROW_INDEX = 2
    return TARGET_ROW_INDEX


def turnSearch(speed, board):
    board.motor_movement([board.M1], board.CW, speed)
    board.motor_movement([board.M2], board.CW, speed)

def turnSearchDirection(speed, board, direction):
    if direction == 'L':
        board.motor_movement([board.M1], board.CCW, speed)
        board.motor_movement([board.M2], board.CCW, speed)
    elif direction == 'R':
        board.motor_movement([board.M1], board.CW, speed)
        board.motor_movement([board.M2], board.CW, speed)


# direction.py
def drive_distance_wBearing(board,
                            dist_delta,
                            bearing_deg,
                            base_speed = 65,     # a touch gentler to avoid wheelspin when snapping from a spin
                            kp_bearing = 1.5,    # a hair stronger steering
                            max_speed = 80,
                            min_speed = 30,      # lower so the inside wheel can slow enough to carve an arc
                            bearing_deadband_deg = 1.2,
                            bearing_clip_deg = 20.0):
    forward = 1 if dist_delta >= 0 else -1

    # deadband + clip for stability
    b = float(bearing_deg)
    if abs(b) < bearing_deadband_deg:
        b = 0.0
    b = max(-bearing_clip_deg, min(bearing_clip_deg, b))

    corr = kp_bearing * b  # +b => speed up left / slow right
    vL = base_speed + corr
    vR = base_speed - corr

    vL = max(min_speed, min(max_speed, vL))
    vR = max(min_speed, min(max_speed, vR))

    if forward == 1:
        board.motor_movement([board.M1], board.CCW, vL)
        board.motor_movement([board.M2], board.CW,  vR)
    else:
        board.motor_movement([board.M1], board.CW,  vL)
        board.motor_movement([board.M2], board.CCW, vR)

    return vL, vR
