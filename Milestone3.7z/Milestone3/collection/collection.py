import serial
import time
import glob

# --- Auto-detect Arduino port ---
def find_arduino_port():
    ports = glob.glob('/dev/ttyACM*') + glob.glob('/dev/ttyUSB*')
    if not ports:
        raise IOError("No Arduino detected on /dev/ttyACM* or /dev/ttyUSB*")
    return ports[0]

# --- Serial setup ---
PORT = find_arduino_port()
BAUD = 9600

print(f"Connecting to Arduino on {PORT}...")
arduino = serial.Serial(PORT, BAUD, timeout=2)
time.sleep(2)  # wait for Arduino to reset

if arduino.in_waiting:
    print(arduino.readline().decode().strip())

servo_close_def = {'Ball': 80, 'Bowl': 80, 'Cube': 80, 'Oil Bottle': 30, 'Mug': 70, 'Weetbix': 120}

# --- Servo IDs ---
SERVO_LEFT = 3
SERVO_RIGHT = 1
SERVO_GRAB = 2

# --- Send command helper ---
def move_servo(servo, angle):
    """Tell Arduino which servo to move and to what angle."""
    angle = max(0, min(180, int(angle)))  # clamp 0–180
    cmd = f"{servo} {angle}\n"
    arduino.write(cmd.encode())
    print(f"→ Sent: Servo {servo} → {angle}°")
    time.sleep(0.05)

# --- Trigger a distance ping ---
def trigger_ping(timeout=1.0):
    """Ask Arduino to perform one ultrasonic measurement. Returns cm (float) or None."""
    # Flush any stale lines so we read the response to *this* request
    try:
        arduino.reset_input_buffer()
    except Exception:
        pass
    arduino.write(b"0 0\n")  # servoNum=0 triggers ping
    distance = readDistance(arduino, timeout=timeout)
    # if distance == None:
    #     while distance == None:
    #         print("usD is receiving none")
    #         distance = readDistance(arduino, timeout=timeout)

    if distance == None:
        print("i am detecting None here for trigger")
        distance = trigger_ping()
    return distance

# --- Read latest distance ---
def readDistance(ser=arduino, timeout=2.0):
    """Return distance in cm as float; None on timeout or 'No echo'."""
    end = time.time() + timeout
    while time.time() < end:
        line = ser.readline().decode(errors='ignore').strip()
        if not line:
            continue
        # Fast-path: Arduino may say 'No echo'
        if line.lower().startswith("no echo"):
            return None
        try:
            return float(line)   # distance in cm
        except ValueError:
            # ignore unrelated lines and keep waiting
            continue
    return None


# --- High-level arm positions ---
def centre():
    move_servo(SERVO_LEFT, 130)
    move_servo(SERVO_RIGHT, 50)



def level_1():
    move_servo(SERVO_LEFT, 75)
    move_servo(SERVO_RIGHT, 105)

def level_2():
    move_servo(SERVO_LEFT, 40)
    move_servo(SERVO_RIGHT, 140)

def level_3():
    move_servo(SERVO_LEFT, 0)
    move_servo(SERVO_RIGHT, 180)

def ramp_height():
    move_servo(SERVO_LEFT, 45)
    move_servo(SERVO_RIGHT, 135)

def open_grabber():
    move_servo(SERVO_GRAB, 180)

def close_grabber(object):
    move_servo(SERVO_GRAB, servo_close_def[object])

# --- Example sequence ---
def main():
    try:
        print("Starting test sequence...")
        time.sleep(2)
        level_3()
        time.sleep(3)
        level_2()
        time.sleep(3)
        level_1()
        time.sleep(3)
        ramp_height()
        time.sleep(3)
        centre()
        time.sleep(3)
        open_grabber()
        time.sleep(3)
        close_grabber('Ball')
        time.sleep(3)
        level_1()

        while True:
            time.sleep(0.5)
            a = trigger_ping()
            print("Distance:",a)

        #open_grabber()
        # time.sleep(2)
        # #close_grabber()
        # #level_3()
        # time.sleep(1)
    finally:
        arduino.close()
        print("Serial connection closed.")

if __name__ == "__main__":
    main()
