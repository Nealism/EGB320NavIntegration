'''Image processing module for obstacle detection'''
import math
import cv2
import numpy as np
from itertools import combinations

class ColourProfile:
    '''Defines a colour profile in HSV space'''
    def __init__(self, name, h_min, h_max, s_min, s_max, v_min, v_max, colour_bgr):
        self.name = name
        self.lower = np.array([h_min, s_min, v_min])
        self.upper = np.array([h_max, s_max, v_max])
        self.colour_bgr = colour_bgr

# --- Module-level configuration ---
# Colour profiles
GREEN = ColourProfile("Green", 50, 92, 55, 255, 20, 255, (0, 255, 0))  # Probably scale up Hmin
ORANGE = ColourProfile("Orange", 0, 21, 100, 255, 50, 255, (0, 140, 255)) 
BLUE = ColourProfile("Blue", 100, 150, 160, 255, 20, 255, (255, 0, 0))
BLACK = ColourProfile("Black", 0, 190, 0, 220, 0, 85, (0, 0, 255))
LOWER_RED = ColourProfile("Red", 0, 0, 120, 255, 120, 255, (0, 0, 255))
UPPER_RED = ColourProfile("Red", 165, 179, 120, 255, 120, 255, (0, 0, 255))
WHITE = ColourProfile("White", 0, 255, 0, 255, 100, 255, (255, 255, 255))
WALL = ColourProfile("Wall",25,95,0,35,190,255,(255,255,255)) 
YELLOW = ColourProfile("Yellow",20,35,80,255,0,255,(255,255,0))
COLOURS = [ORANGE, BLACK, YELLOW, WALL]

# Object type constants
TYPE_ROW_MARKER = "Row Marker"
TYPE_PICKING_STATION = "Picking Station"
TYPE_CUBE = "Cube"
TYPE_BALL = "Soccer Ball"
TYPE_BLOCK = "Block"
TYPE_MUG = "Mug"
TYPE_OIL = "Oil Bottle"
TYPE_BOWL = "Bowl"
TYPE_YELLOW_STATION = "Yellow Station"
TYPE_OBSTACLE_FLOOR = "Floor Obstacle"
TYPE_OBSTACLE_TALL = "Tall Obstacle"
TYPE_SHELF = "Shelf"

# Object detection parameters
CIRCULARITY_THRESHOLD = 0.81  # For detecting circular objects
ASPECT_RATIO_THRESHOLD = 1.5  # For distinguishing wide vs tall objects
HEIGHT_WIDTH_RATIO_THRESHOLD = 1.8  # For very tall objects like oil bottle

# Real-world widths in meters
REAL_SIZES = {
    TYPE_ROW_MARKER: 0.065,  # Black circular marker
    TYPE_PICKING_STATION: 0.047,  # Black square marker
    TYPE_CUBE: 0.04,        # Orange cube
    TYPE_BALL: 0.045,        # Soccer ball
    TYPE_BLOCK: 0.065,        # Rectangular block 
    TYPE_MUG: 0.048,         # Mug with handle
    TYPE_OIL: 0.068,          # Oil bottle height
    TYPE_BOWL: 0.04,         # Bowl diameter
    TYPE_YELLOW_STATION: 0.46,
    TYPE_OBSTACLE_FLOOR: 0.35,
    TYPE_OBSTACLE_TALL: 0.05
}

# Processing parameters
KERNEL = np.ones((5, 5), np.uint8)
FOV_WIDTH_DEG = 31.3
FOV_HEIGHT_DEG = 41
FOV_WIDTH_RAD = np.deg2rad(FOV_WIDTH_DEG)
FOV_HEIGHT_RAD = np.deg2rad(FOV_HEIGHT_DEG)
FOCAL_LENGTH_PX_DISTANCE = 1545
FOCAL_LENGTH_PX_BEARING = 1200
WALL_FOCAL_LENGTH_PX_DISTANCE = 1500
CAMERA_HEIGHT_M = 0.123

class Obstacle:
    '''Class representing a detected obstacle'''
    def __init__(self, type_name, centre, area, bearing, distance, shape, colour_bgr, contour=None, station_id=None):
        self.type_name = type_name
        self.centre = centre
        self.area = area
        self.bearing = bearing
        self.distance = distance
        self.shape = shape
        self.colour_bgr = colour_bgr
        self.contour = contour  # Store the actual contour points
        self.station_id = station_id

    def as_dict(self):
        '''Return obstacle attributes as a dictionary'''
        return {
            "type": self.type_name,
            "centre": self.centre,
            "area": self.area,
            "bearing": self.bearing,
            "distance": self.distance,
            "shape": self.shape,
            "station_id": self.station_id
        }

    @staticmethod
    def count_by_type(obstacles):
        """
        Count the number of obstacles by their type
        Args:
            obstacles: List of Obstacle objects
        Returns:
            dict: Dictionary with obstacle types as keys and their counts as values
        """
        counts = {}
        for obstacle in obstacles:
            counts[obstacle.type_name] = counts.get(obstacle.type_name, 0) + 1
        return counts

    @staticmethod
    def filter_by_type(obstacles, type_name):
        """
        Filter obstacles by type
        Args:
            obstacles: List of Obstacle objects
            type_name: Type of obstacles to filter for (e.g., 'Orange', 'Green', etc.)
        Returns:
            list: List of Obstacle objects of the specified type
        """
        return [obs for obs in obstacles if obs.type_name == type_name]

    @staticmethod
    def filter_by_station_id(obstacles, station_id):
        """
        Filter obstacles by station ID
        Args:
            obstacles: List of Obstacle objects
            station_id: Station ID to filter for
        Returns:
            list: List of Obstacle objects with the specified station ID
        """
        return [obs for obs in obstacles if obs.station_id == station_id]


# Processing parameters
KERNEL = np.ones((5, 5), np.uint8)
CIRCLE_PARAM = 0.83
MIN_AREA = 900
SHELF_SIZE_THRESHOLD = 1000

# --- Main processing functions ---
def analyse_shape(contour):
    """analyse shape characteristics of a contour"""
    area = cv2.contourArea(contour)
    if area == 0:
        return None
    
    perimeter = cv2.arcLength(contour, True)
    circularity = 4 * math.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
    x, y, w, h = cv2.boundingRect(contour)
    aspect_ratio = float(w) / h if h > 0 else 0
    extent = float(area) / (w * h) if w * h > 0 else 0
    
    return {
        'area': area,
        'circularity': circularity,
        'aspect_ratio': aspect_ratio,
        'extent': extent,
        'width': w,
        'height': h,
        'x': x,
        'y': y
    }

def detect_object_type(contour, colour_name, area, hsv):
    """Determine object type based on shape analysis and colour"""
    shape = analyse_shape(contour)
    if shape is None:
        return None, None
    if colour_name == "Green":
        if shape['height'] / shape['width'] > HEIGHT_WIDTH_RATIO_THRESHOLD:
            return TYPE_OBSTACLE_TALL, "rectangle"
        else:
            return TYPE_OBSTACLE_FLOOR, "rectangle"
    elif colour_name == "Blue":  # Blue shelves don't need specific type
        return TYPE_SHELF, "Rectangle"
    elif colour_name == "Yellow":
        return TYPE_YELLOW_STATION, "rectangle"
    elif colour_name == "Orange":
        # First check for tall objects (oil bottle)
        if shape['height'] / shape['width'] > HEIGHT_WIDTH_RATIO_THRESHOLD:
            return TYPE_OIL, "rectangle"
        
        # Check for circular objects with high circularity
        if shape['circularity'] > 0.84:
            if shape['extent'] > 0.74:  # Soccer ball is very filled
                return TYPE_BALL, "circle"
        
        # Check for cube and block
        if shape['extent'] > 0.87:  # Very high extent for solid shapes
            if abs(shape['aspect_ratio'] - 1.0) < 0.2:  # Very square
                return TYPE_CUBE, "square"
            elif shape['aspect_ratio'] > 1.15:  # Wider than tall
                return TYPE_BLOCK, "rectangle"
        
        if shape['aspect_ratio'] > 1.21:
            if shape['extent'] > 0.75:  # Bowl has medium extent
                return TYPE_BOWL, "circle"
        #print(shape["circularity"])
        #print(shape['aspect_ratio'])
        return TYPE_MUG, "rectangle"
        
    elif colour_name == "Black":
        # Black objects are handled separately in detect_and_group_markers
        return None, None
        
    return None, "unknown"

def calculate_bearing_distance(shape, frame_cx, frame_cy, frame_width, frame_height, real_size=None, obj_type=None, contour=None):
    """
    Calculate bearing (degrees) and distance (meters) to an object.
    Uses contour moments if provided for accurate center.
    """
    # Determine object center
    if contour is not None:
        M = cv2.moments(contour)
        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
        else:
            cx = shape['x'] + shape['width'] // 2
            cy = shape['y'] + shape['height'] // 2
    else:
        cx = shape['x'] + shape['width'] // 2
        cy = shape['y'] + shape['height'] // 2

    dx = cx - frame_cx
    dy = cy - frame_cy

    # Bearing in degrees
    bearing_x = math.degrees(math.atan(dx / FOCAL_LENGTH_PX_BEARING))
    bearing_y = math.degrees(math.atan(dy / FOCAL_LENGTH_PX_BEARING))

    distance = None
    if real_size is not None and obj_type is not None:
        # Pick pixel dimension depending on object type
        if obj_type == TYPE_OIL:  # tall object
            px_size = shape['height']
        elif obj_type in [TYPE_BALL, TYPE_BOWL]:  # circular objects
            px_size = (shape['width'] + shape['height']) / 2
        else:  # default: width
            px_size = shape['width']

        if px_size > 0:
            # Distance using pinhole camera model
            distance = (real_size * FOCAL_LENGTH_PX_DISTANCE) / px_size

    return (bearing_x, bearing_y), distance


def process_frame(frame):
    """Process a single frame to detect obstacles and trajectory"""
    frame_height, frame_width = frame.shape[:2]
    centrex, centrey = frame_width // 2, frame_height // 2

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    hsv = cv2.GaussianBlur(hsv, (9, 9), 0)
    detected_obstacles = []
    trajectory = []

    # --- Yellow presence check (affects wall HSV) ---
    yellow_mask = cv2.inRange(hsv, YELLOW.lower, YELLOW.upper)
    yellow_present = np.any(yellow_mask > 0)

    # Adjust wall detection threshold based on yellow presence
    WALL.lower[2] = 190 if yellow_present else 205

    # --- Iterate through all colour profiles ---
    for colour in COLOURS:
        mask = cv2.inRange(hsv, colour.lower, colour.upper)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # === WALL DETECTION ===
        if colour.name == "Wall":
            wall_mask = cv2.inRange(hsv, colour.lower, colour.upper)

            # --- Morphological cleanup ---
            wall_mask = cv2.morphologyEx(wall_mask, cv2.MORPH_CLOSE, KERNEL, iterations=2)
            wall_mask = cv2.morphologyEx(wall_mask, cv2.MORPH_OPEN, KERNEL, iterations=2)

            wall_contours, _ = cv2.findContours(wall_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if wall_contours:    
                # Pick the largest contour
                largest_cnt = max(wall_contours, key=cv2.contourArea)

                # Compute contour centroid
                M = cv2.moments(largest_cnt)
                if M["m00"] != 0:
                    centre_x = int(M["m10"] / M["m00"])
                    centre_y = int(M["m01"] / M["m00"])
                else:
                    x, y, w, h = cv2.boundingRect(largest_cnt)
                    centre_x = x + w // 2
                    centre_y = y + h // 2

                # Bottom-most pixel (used for wall distance)
                bottom_y = largest_cnt[:, :, 1].max()
                # Fit a line to the lower edge of the wall contour
                [vx, vy, x0, y0] = cv2.fitLine(largest_cnt, cv2.DIST_L2, 0, 0.01, 0.01)
                # Two points along the fitted line for visualization and angle
                line_length = frame_width
                x1 = int(x0 - vx * line_length)
                y1 = int(y0 - vy * line_length)
                x2 = int(x0 + vx * line_length)
                y2 = int(y0 + vy * line_length)
                line_pts = ((x1, y1), (x2, y2))

                # Then call with full info
                wall_dist, wall_bearing = wall_distance_and_bearing(line_pts, bottom_y, frame_width, frame_height)

                detected_obstacles.append(
                    Obstacle(
                        type_name="Wall",
                        centre=(centre_x, centre_y),
                        area=cv2.contourArea(largest_cnt),
                        bearing=(wall_bearing, 0.0),
                        distance=wall_dist,
                        shape="Line",
                        colour_bgr=WALL.colour_bgr,
                        contour=largest_cnt,
                    )
                )
            # Skip to next colour
            continue

        # === BLACK MARKER HANDLING ===
        if colour.name == "Black":
            black_groups = detect_and_group_markers(hsv, mask, contours, WHITE, centrex, centrey)
            detected_obstacles.extend(black_groups)
            continue
        
        # near top of module (module-level)
        YELLOW_MIN_COVERAGE = 0.39   # fraction of frame width required to consider a large yellow station
        # inside process_frame loop, where you check for colour.name == "Yellow":
        if colour.name == "Yellow":
            if not contours:
                continue

            for cnt in contours:
                x, y, w, h = cv2.boundingRect(cnt)
                frame_w = frame.shape[1]
                area = cv2.contourArea(cnt)

                # quick debug
                # print(f"[Y] w/frame_w={w/frame_w:.2f}, area={area}")

                # Require both a minimum width coverage OR a minimum area,
                # otherwise ignore (prevents quarter-frame false positives).
                width_ok = (float(w) >= YELLOW_MIN_COVERAGE * frame_w)
            
                # Optionally compute mask coverage ratio inside bounding box:
                # mask_box = mask[y:y+h, x:x+w]
                # black = cv2.countNonZero(mask_box)
                # fill_ratio = black / (w*h) if w*h>0 else 0

                if not (width_ok):
                    # too small/insufficient coverage, ignore
                    continue

                # compute centroid (use moments)
                M = cv2.moments(cnt)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                else:
                    cx, cy = x + w // 2, y + h // 2

                shape_info = {'x': x, 'y': y, 'width': w, 'height': h, 'area': area}

                real_size = REAL_SIZES.get(TYPE_YELLOW_STATION, 0.46)

                bearing, distance = calculate_bearing_distance(
                    shape_info,
                    centrex, centrey,
                    frame_w,
                    frame.shape[0],
                    real_size,
                    TYPE_YELLOW_STATION,
                    contour=cnt
                )

                detected_obstacles.append(
                    Obstacle(
                        TYPE_YELLOW_STATION,
                        (cx, cy),
                        shape_info['area'],
                        bearing,
                        distance,
                        "Rectangle",
                        colour.colour_bgr,
                        cnt
                    )
                )

            # Skip the generic detection for yellow
            continue



        # === NORMAL OBJECT DETECTION ===
        for cnt in contours:
            shape_info = analyse_shape(cnt)
            if shape_info is None or shape_info["area"] < MIN_AREA:
                continue

            # Skip small blue shapes (not shelves)
            if colour.name == "Blue" and shape_info["area"] < SHELF_SIZE_THRESHOLD:
                continue

            obj_type, shape_type = detect_object_type(cnt, colour.name, shape_info["area"], hsv)
            if obj_type is None:
                continue

            centre = (
                shape_info["x"] + shape_info["width"] // 2,
                shape_info["y"] + shape_info["height"] // 2,
            )

            bearing, distance_m = calculate_bearing_distance(
                shape_info,
                centrex,
                centrey,
                frame_width,
                frame_height,
                REAL_SIZES.get(obj_type),
                obj_type,
                contour=cnt,
            )

            detected_obstacles.append(
                Obstacle(
                    type_name=obj_type,
                    centre=centre,
                    area=shape_info["area"],
                    bearing=bearing,
                    distance=distance_m,
                    shape=shape_type if shape_type else "unknown",
                    colour_bgr=colour.colour_bgr,
                    contour=cnt,
                )
            )
            trajectory.append(centre)

    return detected_obstacles, trajectory

def detect_and_group_markers(hsv, mask, input_contours, white_profile, centrex, centrey):
    """
    Detect and group black markers into picking stations or row markers.
    - Prune small contours first
    - Apply type-specific white border thresholds
    - Remove picking stations if any row markers exist
    - Return grouped obstacles
    """
    detected_groups = []
    black_contours_info = []
    frame_height, frame_width = hsv.shape[:2]

    # White border thresholds per type
    ROW_MARKER_WHITE_THRESH = 0.62 # during afternoon light 0.7
    PICKING_STATION_WHITE_THRESH = 0.62 # during afternoon light 0.63

    # --- Step 0: pre-check if any row markers exist ---
    row_marker_exists = False
    for cnt in input_contours:
        area = cv2.contourArea(cnt)
        if area < 500:
            continue
        x, y, w, h = cv2.boundingRect(cnt)
        aspect_ratio = w / h if h > 0 else 0
        perimeter = cv2.arcLength(cnt, True)
        circularity = 4 * math.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
        if circularity > 0.85 and 0.8 < aspect_ratio < 1.2 and y > frame_height * 0.15:
            row_marker_exists = True
            break

    # --- Step 1: process each contour ---
    for cnt in input_contours:
        area = cv2.contourArea(cnt)
        if area < 500:  # prune small noise
            continue

        x, y, w, h = cv2.boundingRect(cnt)
        aspect_ratio = w / h if h > 0 else 0
        perimeter = cv2.arcLength(cnt, True)
        circularity = 4 * math.pi * area / (perimeter * perimeter) if perimeter > 0 else 0

        # Decide marker type
        if circularity > 0.85 and 0.8 < aspect_ratio < 1.2 and y > frame_height * 0.15:
            type_name = TYPE_ROW_MARKER
            white_thresh = ROW_MARKER_WHITE_THRESH
        else:
            type_name = TYPE_PICKING_STATION
            white_thresh = PICKING_STATION_WHITE_THRESH

        # Skip picking stations if row markers exist
        if type_name == TYPE_PICKING_STATION and row_marker_exists:
            continue

        # White border check
        if not has_white_border(hsv, cnt, white_profile, fraction_thresh=white_thresh):
            continue

        # Calculate distance and bearing
        shape_info = {'x': x, 'y': y, 'width': w, 'height': h}
        bearing, distance = calculate_bearing_distance(
            shape_info,
            centrex, centrey,
            frame_width, frame_height,
            REAL_SIZES[type_name],
            type_name
        )

        black_contours_info.append({
            'contour': cnt,
            'shape': shape_info,
            'bearing': bearing,
            'distance': distance,
            'type': type_name
        })

    # --- Step 2: group contours by proximity/distance ---
    if not black_contours_info:
        return []

    row_contours, merged_mask = group_same_markers_distance(black_contours_info, hsv.shape)

    # --- Step 3: assign group properties ---
    for row in row_contours:
        row_mask = np.zeros_like(merged_mask)
        cv2.drawContours(row_mask, [row], -1, 255, -1)
        group_infos = [
            info for info in black_contours_info
            if row_mask[int(info['shape']['y'] + info['shape']['height']/2),
                        int(info['shape']['x'] + info['shape']['width']/2)] == 255
        ]
        if not group_infos:
            continue

        avg_distance = sum(info['distance'] for info in group_infos) / len(group_infos)
        avg_bearing_x = sum(info['bearing'][0] for info in group_infos) / len(group_infos)
        avg_bearing_y = sum(info['bearing'][1] for info in group_infos) / len(group_infos)
        avg_bearing = (avg_bearing_x, avg_bearing_y)

        x, y, w, h = cv2.boundingRect(row)
        centre = (x + w//2, y + h//2)
        area = cv2.contourArea(row)
        type_name = group_infos[0]['type']

        detected_groups.append(
            Obstacle(
                type_name=type_name,
                centre=centre,
                area=area,
                bearing=avg_bearing,
                distance=avg_distance,
                shape="group",
                colour_bgr=BLACK.colour_bgr,
                contour=row,
                station_id=len(group_infos)
            )
        )

    return detected_groups

def group_same_markers_distance(black_contours_info, frame_shape):
    """
    Group black markers based on distance rather than morphological dilation.
    Returns group contours and a synthetic mask (like the old version).
    Applies higher threshold for picking station markers.
    """
    if not black_contours_info:
        return [], np.zeros(frame_shape[:2], dtype=np.uint8)

    contour_infos = []
    for info in black_contours_info:
        cnt = info['contour']
        type_name = info['type']
        x, y, w, h = cv2.boundingRect(cnt)
        cx, cy = x + w // 2, y + h // 2
        contour_infos.append({
            'contour': cnt,
            'centre': (cx, cy),
            'size': (w + h) / 2,
            'type': type_name
        })

    avg_size = np.mean([info['size'] for info in contour_infos])

    # Different scaling factors per type
    base_thresh = avg_size
    row_thresh_mult = 2.5     # normal grouping
    station_thresh_mult = 3.25  # larger grouping for picking stations

    parent = list(range(len(contour_infos)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        pi, pj = find(i), find(j)
        if pi != pj:
            parent[pj] = pi

    for i, j in combinations(range(len(contour_infos)), 2):
        ci, cj = contour_infos[i]['centre'], contour_infos[j]['centre']
        ti, tj = contour_infos[i]['type'], contour_infos[j]['type']
        dist = math.dist(ci, cj)

        # Use the higher threshold if either contour is a picking station
        if TYPE_PICKING_STATION in (ti, tj):
            thresh = base_thresh * station_thresh_mult
        else:
            thresh = base_thresh * row_thresh_mult

        if dist < thresh:
            union(i, j)

    groups = {}
    for idx, info in enumerate(contour_infos):
        root = find(idx)
        groups.setdefault(root, []).append(info)

    group_contours = []
    merged_mask = np.zeros(frame_shape[:2], dtype=np.uint8)

    for members in groups.values():
        cnts = [m['contour'] for m in members]
        merged = np.vstack(cnts)
        hull = cv2.convexHull(merged)
        group_contours.append(hull)
        cv2.drawContours(merged_mask, [hull], -1, 255, -1)  # fill merged mask

    return group_contours, merged_mask

def has_white_border(hsv, cnt, white_profile, fraction_thresh=0.6):
    contour_mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
    cv2.drawContours(contour_mask, [cnt], -1, 255, -1)
    kernel = np.ones((7,7), np.uint8)
    dilated_mask = cv2.dilate(contour_mask, kernel, iterations=1)
    ring_mask = dilated_mask - contour_mask
    colours_around_contour = hsv[ring_mask == 255]
    if colours_around_contour.size == 0:
        return False
    white_pixels = np.all((colours_around_contour >= white_profile.lower) & (colours_around_contour <= white_profile.upper), axis=1)
    white_fraction = np.sum(white_pixels) / len(colours_around_contour)
    return white_fraction >= fraction_thresh

def wall_distance_and_bearing(line_pts, transition_y, img_width, img_height):
    """
    Estimate distance and bearing to the wall based on the floor-wall intersection line.
    +right / -left bearing convention.
    """
    (x1, y1), (x2, y2) = line_pts

    # --- Distance from transition ---
    center_y = img_height / 2
    dy = transition_y - center_y
    if dy == 0:
        dy = 1
    distance_m = (CAMERA_HEIGHT_M * WALL_FOCAL_LENGTH_PX_DISTANCE) / dy

    # --- Bearing from wall line orientation ---
    dx = x2 - x1
    dy_line = y2 - y1

    # Angle of wall line in image coords (radians)
    #wall_angle = math.atan2(dy_line, dx)

    # Normal points toward the camera (perpendicular)
    #wall_normal = wall_angle + math.pi / 2

    # Compute the wall’s midpoint relative to image center
    #mid_x = (x1 + x2) / 2
    #center_x = img_width / 2

    # Determine sign based on which side the wall lies on
    #if mid_x < center_x:
        # Wall on left → bearing negative
     #   bearing_rad = -(wall_normal - math.pi / 2)
    #else:
        # Wall on right → bearing positive
     #   bearing_rad = (wall_normal - math.pi / 2)

    #bearing_deg = math.degrees(bearing_rad)
    bearing_deg = 0.0  # Simplified to zero for straight-ahead wall
    return distance_m, bearing_deg


